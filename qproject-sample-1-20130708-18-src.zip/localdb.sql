create table if not exists q
(
  id integer auto_increment primary key
);
