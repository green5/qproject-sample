<?php

class XMath {
	public function __construct(){}
	static $PI;
	static $NaN;
	static $POSITIVE_INFINITY;
	static $NEGATIVE_INFINITY;
	static function isNaN($f) {
		return is_nan($f);
	}
	static function isFinite($f) {
		return is_finite($f);
	}
	function __toString() { return 'Math'; }
}
{
	XMath::$PI = M_PI;
	XMath::$NaN = acos(1.01);
	XMath::$NEGATIVE_INFINITY = log(0);
	XMath::$POSITIVE_INFINITY = -XMath::$NEGATIVE_INFINITY;
}
