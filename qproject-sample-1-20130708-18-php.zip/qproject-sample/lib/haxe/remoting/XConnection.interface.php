<?php

interface haxe_remoting_XConnection {
}
