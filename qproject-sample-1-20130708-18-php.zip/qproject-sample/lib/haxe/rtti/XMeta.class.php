<?php

class haxe_rtti_XMeta {
	public function __construct(){}
	static function getType($t) {
		$meta = $t->__meta__;
		return haxe_rtti_XMeta_0($meta, $t);
	}
	function __toString() { return 'haxe.rtti.Meta'; }
}
function haxe_rtti_XMeta_0(&$meta, &$t) {
	if($meta === null || _hx_field($meta, "obj") === null) {
		return _hx_anonymous(array());
	} else {
		return $meta->obj;
	}
}
