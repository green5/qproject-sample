<?php

class haxe_unit_XTestRunner {
	public function __construct() {
		if(!php_XBoot::$skip_constructor) {
		$this->result = new haxe_unit_XTestResult();
		$this->cases = new XHList();
	}}
	public function runCase($t) {
		$old = haxe_XLog::$trace;
		haxe_XLog::$trace = (isset(haxe_unit_XTestRunner::$customTrace) ? haxe_unit_XTestRunner::$customTrace: array("haxe_unit_XTestRunner", "customTrace"));
		$cl = XType::getClass($t);
		$fields = XType::getInstanceFields($cl);
		haxe_unit_XTestRunner::hprint("Class: " . _hx_string_or_null(XType::getClassName($cl)) . " ");
		{
			$_g = 0;
			while($_g < $fields->length) {
				$f = $fields[$_g];
				++$_g;
				$fname = $f;
				$field = XReflect::field($t, $f);
				if(XStringTools::startsWith($fname, "test") && XReflect::isFunction($field)) {
					$t->currentTest = new haxe_unit_XTestStatus();
					$t->currentTest->classname = XType::getClassName($cl);
					$t->currentTest->method = $fname;
					$t->setup();
					try {
						XReflect::callMethod($t, $field, new _hx_array(array()));
						if($t->currentTest->done) {
							$t->currentTest->success = true;
							haxe_unit_XTestRunner::hprint(".");
						} else {
							$t->currentTest->success = false;
							$t->currentTest->error = "(warning) no assert";
							haxe_unit_XTestRunner::hprint("W");
						}
					}catch(Exception $__hx__e) {
						$_ex_ = ($__hx__e instanceof HException) ? $__hx__e->e : $__hx__e;
						if(($e = $_ex_) instanceof haxe_unit_XTestStatus){
							haxe_unit_XTestRunner::hprint("F");
							$t->currentTest->backtrace = haxe_XCallStack::toString(haxe_XCallStack::exceptionStack());
						}
						else { $e2 = $_ex_;
						{
							haxe_unit_XTestRunner::hprint("E");
							$t->currentTest->error = "exception thrown : " . XStd::string($e2);
							$t->currentTest->backtrace = haxe_XCallStack::toString(haxe_XCallStack::exceptionStack());
						}}
					}
					$this->result->add($t->currentTest);
					$t->tearDown();
					unset($e2,$e);
				}
				unset($fname,$field,$f);
			}
		}
		haxe_unit_XTestRunner::hprint("\x0A");
		haxe_XLog::$trace = $old;
	}
	public function run() {
		$this->result = new haxe_unit_XTestResult();
		if(null == $this->cases) throw new HException('null iterable');
		$__hx__it = $this->cases->iterator();
		while($__hx__it->hasNext()) {
			$c = $__hx__it->next();
			$this->runCase($c);
		}
		haxe_unit_XTestRunner::hprint($this->result->toString());
		return $this->result->success;
	}
	public function add($c) {
		$this->cases->add($c);
	}
	public $cases;
	public $result;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function hprint($v) { return call_user_func_array(self::$hprint, array($v)); }
	public static $hprint = null;
	static function customTrace($v, $p = null) {
		haxe_unit_XTestRunner::hprint(_hx_string_or_null($p->fileName) . ":" . _hx_string_rec($p->lineNumber, "") . ": " . XStd::string($v) . "\x0A");
	}
	function __toString() { return 'haxe.unit.TestRunner'; }
}
haxe_unit_XTestRunner::$hprint = array(new _hx_lambda(array(), "haxe_unit_XTestRunner_0"), 'execute');
function haxe_unit_XTestRunner_0($v) {
	{
		php_XLib::hprint($v);
	}
}
