<?php

class haxe_unit_XTestResult {
	public function __construct() {
		if(!php_XBoot::$skip_constructor) {
		$this->m_tests = new XHList();
		$this->success = true;
	}}
	public function toString() {
		$buf = new XStringBuf();
		$failures = 0;
		if(null == $this->m_tests) throw new HException('null iterable');
		$__hx__it = $this->m_tests->iterator();
		while($__hx__it->hasNext()) {
			$test = $__hx__it->next();
			if($test->success === false) {
				$buf->add("* ");
				$buf->add($test->classname);
				$buf->add("::");
				$buf->add($test->method);
				$buf->add("()");
				$buf->add("\x0A");
				$buf->add("ERR: ");
				if(_hx_field($test, "posInfos") !== null) {
					$buf->add($test->posInfos->fileName);
					$buf->add(":");
					$buf->add($test->posInfos->lineNumber);
					$buf->add("(");
					$buf->add($test->posInfos->className);
					$buf->add(".");
					$buf->add($test->posInfos->methodName);
					$buf->add(") - ");
				}
				$buf->add($test->error);
				$buf->add("\x0A");
				if($test->backtrace !== null) {
					$buf->add($test->backtrace);
					$buf->add("\x0A");
				}
				$buf->add("\x0A");
				$failures++;
			}
		}
		$buf->add("\x0A");
		if($failures === 0) {
			$buf->add("OK ");
		} else {
			$buf->add("FAILED ");
		}
		$buf->add($this->m_tests->length);
		$buf->add(" tests, ");
		$buf->add($failures);
		$buf->add(" failed, ");
		$buf->add($this->m_tests->length - $failures);
		$buf->add(" success");
		$buf->add("\x0A");
		return $buf->b;
	}
	public function add($t) {
		$this->m_tests->add($t);
		if(!$t->success) {
			$this->success = false;
		}
	}
	public $success;
	public $m_tests;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return $this->toString(); }
}
