<?php

class haxe_io_XEof {
	public function __construct(){}
	public function toString() {
		return "Eof";
	}
	function __toString() { return $this->toString(); }
}
