<?php

class haxe_io_XBytes {
	public function __construct($length, $b) {
		if(!php_XBoot::$skip_constructor) {
		$this->length = $length;
		$this->b = $b;
	}}
	public function toString() {
		return $this->b;
	}
	public function compare($other) {
		return $this->b < $other->b ? -1 : ($this->b == $other->b ? 0 : 1);
	}
	public $b;
	public $length;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function alloc($length) {
		return new haxe_io_XBytes($length, str_repeat(chr(0), $length));
	}
	static function ofString($s) {
		return new haxe_io_XBytes(strlen($s), $s);
	}
	function __toString() { return $this->toString(); }
}
