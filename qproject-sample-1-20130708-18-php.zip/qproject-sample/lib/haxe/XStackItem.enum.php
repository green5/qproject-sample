<?php

class haxe_XStackItem extends Enum {
	public static $CFunction;
	public static function FilePos($s, $file, $line) { return new haxe_XStackItem("FilePos", 2, array($s, $file, $line)); }
	public static function Lambda($v) { return new haxe_XStackItem("Lambda", 4, array($v)); }
	public static function Method($classname, $method) { return new haxe_XStackItem("Method", 3, array($classname, $method)); }
	public static function Module($m) { return new haxe_XStackItem("Module", 1, array($m)); }
	public static $__constructors = array(0 => 'CFunction', 2 => 'FilePos', 4 => 'Lambda', 3 => 'Method', 1 => 'Module');
	}
haxe_XStackItem::$CFunction = new haxe_XStackItem("CFunction", 0);
