<?php

class utils_XURLParser {
	public function __construct($url) {
		if(!php_XBoot::$skip_constructor) {
		$this->url = $url;
		$r = new XEReg("^(?:(?![^:@]+:[^:@/]*@)([^:/?#.]+):)?(?://)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:/?#]*)(?::(\\d*))?)(((/(?:[^?#](?![^?#/]*\\.[^?#/.]+(?:[?#]|\$)))*/?)?([^?#/]*))(?:\\?([^#]*))?(?:#(.*))?)", "");
		$this->ok = $r->match($url);
		{
			$_g1 = 0; $_g = utils_XURLParser::$_parts->length;
			while($_g1 < $_g) {
				$i = $_g1++;
				$this->{utils_XURLParser::$_parts[$i]} = $r->matched($i);
				unset($i);
			}
		}
	}}
	public function test() {
		$s = "For Url -> " . _hx_string_or_null($this->url) . "\x0A";
		{
			$_g1 = 0; $_g = utils_XURLParser::$_parts->length;
			while($_g1 < $_g) {
				$i = $_g1++;
				$s .= _hx_string_or_null(utils_XURLParser::$_parts[$i]) . ":[" . XStd::string(XReflect::field($this, utils_XURLParser::$_parts[$i])) . "]\x0A";
				unset($i);
			}
		}
		$s .= "query:" . XStd::string($this->desplit("query")) . "\x0A";
		$s .= "anchor:" . XStd::string($this->desplit("anchor")) . "\x0A";
		return $s;
	}
	public function toString() {
		return $this->source;
	}
	public function desplit($key = null) {
		if($key === null) {
			$key = "query";
		}
		$ret = _hx_anonymous(array());
		$str = XReflect::field($this, $key);
		if($str !== null) {
			$_g = 0; $_g1 = _hx_explode("&", $str);
			while($_g < $_g1->length) {
				$pp = $_g1[$_g];
				++$_g;
				$i = _hx_index_of($pp, "=", null);
				if($i < 0) {
					$ret->{$pp} = true;
					continue;
				}
				$k = _hx_substring($pp, 0, $i);
				$v = _hx_substring($pp, $i + 1, null);
				$k = urldecode($k);
				$v = urldecode($v);
				$ret->{$k} = $v;
				unset($v,$pp,$k,$i);
			}
		}
		return $ret;
	}
	public $anchor;
	public $query;
	public $file;
	public $directory;
	public $path;
	public $relative;
	public $port;
	public $host;
	public $password;
	public $user;
	public $userInfo;
	public $authority;
	public $protocol;
	public $source;
	public $ok;
	public $url;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static $_parts;
	static function parse($url) {
		return new utils_XURLParser($url);
	}
	function __toString() { return $this->toString(); }
}
utils_XURLParser::$_parts = new _hx_array(array("source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"));
