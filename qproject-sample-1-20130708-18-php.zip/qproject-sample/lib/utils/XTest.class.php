<?php

class utils_XTest extends haxe_unit_XTestCase {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	public function testtest() {
		$err = "";
		{
			$_g = 0; $_g1 = utils_XTest::$u2;
			while($_g < $_g1->length) {
				$u = $_g1[$_g];
				++$_g;
				try {
					haxe_XLog::trace(utils_XURLParser::parse($u)->test(), _hx_anonymous(array("fileName" => "URLParser.hx", "lineNumber" => 130, "className" => "utils.Test", "methodName" => "testtest")));
				}catch(Exception $__hx__e) {
					$_ex_ = ($__hx__e instanceof HException) ? $__hx__e->e : $__hx__e;
					if(($x = $_ex_) instanceof utils_XTest){
						$err = "" . XStd::string($x);
					} else throw $__hx__e;;
				}
				unset($x,$u);
			}
		}
		$this->assertEquals("", $err, _hx_anonymous(array("fileName" => "URLParser.hx", "lineNumber" => 132, "className" => "utils.Test", "methodName" => "testtest")));
	}
	public function testParse() {
		{
			$_g = 0; $_g1 = utils_XTest::$u1;
			while($_g < $_g1->length) {
				$u = $_g1[$_g];
				++$_g;
				$this->assertEquals($u, utils_XURLParser::parse($u)->toString(), _hx_anonymous(array("fileName" => "URLParser.hx", "lineNumber" => 122, "className" => "utils.Test", "methodName" => "testParse")));
				unset($u);
			}
		}
		{
			$_g = 0; $_g1 = utils_XTest::$u2;
			while($_g < $_g1->length) {
				$u = $_g1[$_g];
				++$_g;
				$this->assertEquals($u, utils_XURLParser::parse($u)->toString(), _hx_anonymous(array("fileName" => "URLParser.hx", "lineNumber" => 123, "className" => "utils.Test", "methodName" => "testParse")));
				unset($u);
			}
		}
	}
	static $u1;
	static $u2;
	function __toString() { return 'utils.Test'; }
}
utils_XTest::$u1 = new _hx_array(array("/hello/world/there.html?name=ferret#foo", "foo://username:password@www.example.com:123/hello/world/there.html?name=ferret#foo", "mailto::a@x", "?a=1&b=2", "?a=1&b=2?c=3&d=4", "?T=TLink[pid=:1].user()"));
utils_XTest::$u2 = new _hx_array(array("http://a.com?a=1#c=2&b=2", "?a=1&b=2/3"));
