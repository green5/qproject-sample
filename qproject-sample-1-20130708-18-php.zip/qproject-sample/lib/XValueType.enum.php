<?php

class XValueType extends Enum {
	public static $TBool;
	public static function TClass($c) { return new XValueType("TClass", 6, array($c)); }
	public static function TEnum($e) { return new XValueType("TEnum", 7, array($e)); }
	public static $TFloat;
	public static $TFunction;
	public static $TInt;
	public static $TNull;
	public static $TObject;
	public static $TUnknown;
	public static $__constructors = array(3 => 'TBool', 6 => 'TClass', 7 => 'TEnum', 2 => 'TFloat', 5 => 'TFunction', 1 => 'TInt', 0 => 'TNull', 4 => 'TObject', 8 => 'TUnknown');
	}
XValueType::$TBool = new XValueType("TBool", 3);
XValueType::$TFloat = new XValueType("TFloat", 2);
XValueType::$TFunction = new XValueType("TFunction", 5);
XValueType::$TInt = new XValueType("TInt", 1);
XValueType::$TNull = new XValueType("TNull", 0);
XValueType::$TObject = new XValueType("TObject", 4);
XValueType::$TUnknown = new XValueType("TUnknown", 8);
