<?php

class php_XLib {
	public function __construct(){}
	static function hprint($v) {
		echo(XStd::string($v));
	}
	static function isCli() {
		return (0 == strncasecmp(PHP_SAPI, 'cli', 3));
	}
	static function hashOfAssociativeArray($arr) {
		$h = new haxe_ds_XStringMap();
		$h->h = $arr;
		return $h;
	}
	static function mail($to, $subject, $message, $additionalHeaders = null, $additionalParameters = null) {
		if(null !== $additionalParameters) {
			return mail($to, $subject, $message, $additionalHeaders, $additionalParameters);
		} else {
			if(null !== $additionalHeaders) {
				return mail($to, $subject, $message, $additionalHeaders);
			} else {
				return mail($to, $subject, $message);
			}
		}
	}
	function __toString() { return 'php.Lib'; }
}
