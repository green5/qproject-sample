<?php

class php_db__PDO_XAllResultSet extends php_db__PDO_XBaseResultSet {
	public function __construct($pdo, $typeStrategy) {
		if(!php_XBoot::$skip_constructor) {
		parent::__construct($pdo,$typeStrategy);
		$this->all = $pdo->fetchAll(PDO::FETCH_NUM);
		$this->pos = 0;
		$this->_length = count($this->all);
	}}
	public function nextRow() {
		return $this->all[$this->pos++];
	}
	public function get_length() {
		return $this->_length;
	}
	public function hasNext() {
		return $this->pos < $this->_length;
	}
	public function getResult($index) {
		if(isset($this->all[0]) && isset($this->all[0][$index])) {
			return $this->all[0][$index];
		} else {
			return null;
		}
	}
	public $_length;
	public $pos;
	public $all;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static $__properties__ = array("get_length" => "get_length","get_nfields" => "get_nfields");
	function __toString() { return 'php.db._PDO.AllResultSet'; }
}
