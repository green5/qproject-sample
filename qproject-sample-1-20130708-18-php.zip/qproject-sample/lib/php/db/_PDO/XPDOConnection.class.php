<?php

class php_db__PDO_XPDOConnection implements sys_db_XConnection{
	public function __construct($dsn, $user = null, $password = null, $options = null) {
		if(!php_XBoot::$skip_constructor) {
		if(null === $options) {
			$this->pdo = new PDO($dsn, $user, $password);
		} else {
			$arr = array();
			{
				$_g = 0; $_g1 = XReflect::fields($options);
				while($_g < $_g1->length) {
					$key = $_g1[$_g];
					++$_g;
					$arr[$key] = XReflect::field($options, $key);
					unset($key);
				}
			}
			$this->pdo = new PDO($dsn, $user, $password, $arr);
		}
		$this->dbname = _hx_explode(":", $dsn)->shift();
	}}
	public function base16_encode($str) {
		$str = unpack("H" . _hx_string_rec(2 * strlen($str), ""), $str);
		$str = chunk_split($str[1]);
		return $str;
	}
	public function rollback() {
		$this->pdo->rollBack();
	}
	public function commit() {
		$this->pdo->commit();
	}
	public function startTransaction() {
		$this->pdo->beginTransaction();
	}
	public function dbName() {
		return $this->dbname;
	}
	public function lastInsertId() {
		return XStd::parseInt($this->pdo->lastInsertId(null));
	}
	public function addValue($s, $v) {
		if(is_int($v) || is_null($v)) {
			$s->add($v);
		} else {
			if(is_bool($v)) {
				$s->add((($v) ? 1 : 0));
			} else {
				$s->add($this->quote(XStd::string($v)));
			}
		}
	}
	public function quote($s) {
		if(_hx_index_of($s, "\x00", null) >= 0) {
			return "x'" . _hx_string_or_null($this->base16_encode($s)) . "'";
		}
		return $this->pdo->quote($s, null);
	}
	public function escape($s) {
		$output = $this->pdo->quote($s, null);
		return ((strlen($output) > 2) ? _hx_substr($output, 1, strlen($output) - 2) : $output);
	}
	public function request($s) {
		$result = $this->pdo->query($s, PDO::PARAM_STR);
		if(($result === false)) {
			$info = new _hx_array($this->pdo->errorInfo());
			throw new HException("Error while executing " . _hx_string_or_null($s) . " (" . _hx_string_or_null($info[2]) . ")");
		}
		$db = strtolower($this->dbname);
		switch($db) {
		case "sqlite":{
			return new php_db__PDO_XAllResultSet($result, new php_db__PDO_XDBNativeStrategy($db));
		}break;
		default:{
			return new php_db__PDO_XPDOResultSet($result, new php_db__PDO_XPHPNativeStrategy());
		}break;
		}
	}
	public function close() {
		$this->pdo = null;
		unset($this->pdo);
	}
	public $dbname;
	public $pdo;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return 'php.db._PDO.PDOConnection'; }
}
