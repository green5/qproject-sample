<?php

class php_db_XPDO {
	public function __construct(){}
	static function open($dsn, $user = null, $password = null, $options = null) {
		return new php_db__PDO_XPDOConnection($dsn, $user, $password, $options);
	}
	function __toString() { return 'php.db.PDO'; }
}
