<?php

class php_XWeb {
	public function __construct(){}
	static function getParams() {
		$a = array_merge($_GET, $_POST);
		if(get_magic_quotes_gpc()) {
			reset($a); while(list($k, $v) = each($a)) $a[$k] = stripslashes((string)$v);
		}
		return php_XLib::hashOfAssociativeArray($a);
	}
	static function getClientHeader($k) {
		$k1 = php_XWeb_0($k);
		if(null == php_XWeb::getClientHeaders()) throw new HException('null iterable');
		$__hx__it = php_XWeb::getClientHeaders()->iterator();
		while($__hx__it->hasNext()) {
			$i = $__hx__it->next();
			if($i->header === $k1) {
				return $i->value;
			}
		}
		return null;
	}
	static $_client_headers;
	static function getClientHeaders() {
		if(php_XWeb::$_client_headers === null) {
			php_XWeb::$_client_headers = new XHList();
			$h = php_XLib::hashOfAssociativeArray($_SERVER);
			if(null == $h) throw new HException('null iterable');
			$__hx__it = $h->keys();
			while($__hx__it->hasNext()) {
				$k = $__hx__it->next();
				if(_hx_substr($k, 0, 5) === "HTTP_") {
					php_XWeb::$_client_headers->add(_hx_anonymous(array("header" => _hx_substr($k, 5, null), "value" => $h->get($k))));
				}
			}
		}
		return php_XWeb::$_client_headers;
	}
	static function getMethod() {
		if(isset($_SERVER['REQUEST_METHOD'])) {
			return $_SERVER['REQUEST_METHOD'];
		} else {
			return null;
		}
	}
	static $isModNeko;
	function __toString() { return 'php.Web'; }
}
php_XWeb::$isModNeko = !php_XLib::isCli();
function php_XWeb_0(&$k) {
	{
		$s = strtoupper($k);
		return str_replace("-", "_", $s);
	}
}
