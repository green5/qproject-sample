<?php

interface hxqp_XHavingName {
	function name1();
}
