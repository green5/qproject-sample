<?php

class hxqp_XRemote {
	public function __construct() { 
	}
	public function jqGrid($q) {
		$ret = new stdClass();
		
			$ret->page = 1;
			$ret->total = 1;
			$ret->records = 3;
			$ret->rows = array();
		;
		array_push($ret->rows, _hx_deref(new _hx_array(array(10, "jqGridProject", "", "example", " ")))->a);
		return $ret;
	}
	public function bbGrid($type, $url, $rowid, $data) {
		$u = utils_XURLParser::parse($url);
		{
			$bb = _hx_explode("/", $u->query);
			$u->query = $bb[0];
			if($bb->length > 1) {
				$rowid = $bb[1];
			}
		}
		$m = hxqp_XLocalDB::model($u->desplit(null)->T);
		if($m === null) {
			throw new HException("bbGrid: bad url " . _hx_string_or_null($url));
		}
		if($type === "GET") {
			$q = _hx_anonymous(array());
			if($rowid !== "-1" && $u->anchor !== null) {
				$u->anchor = hxqp_XRemote_0($this, $data, $m, $q, $rowid, $type, $u, $url);
				$q = $u->desplit("anchor");
			}
			$ll = $m->manager->dynamicSearch($q);
			$aa = new _hx_array(array());
			if(null == $ll) throw new HException('null iterable');
			$__hx__it = $ll->iterator();
			while($__hx__it->hasNext()) {
				$l = $__hx__it->next();
				$aa->push($m->ui($l));
			}
			return $aa;
		} else {
			if($type === "PUT") {
				$id = _hx_array_get(XReflect::fields($data), 0);
				$q = _hx_anonymous(array());
				$q->{$id} = XReflect::field($data, $id);
				$uu = $m->manager->dynamicSearch($q);
				if($uu->length !== 1) {
					throw new HException("bad.id:[" . _hx_string_or_null($id) . "=" . XStd::string(XReflect::field($data, $id)) . "]");
				}
				$u1 = $uu->first();
				hxqp_XXLib::extend($u1, $data);
				$u1->update();
			} else {
				if($type === "DELETE") {
					$q = _hx_anonymous(array("pid" => $rowid));
					$uu = $m->manager->dynamicSearch($q);
					if($uu->length !== 1) {
						throw new HException("bad.id:" . _hx_string_or_null($rowid));
					}
					$u1 = $uu->first();
					$u1->delete();
				} else {
					if($type === "POST") {
						$id = _hx_array_get(XReflect::fields($data), 0);
						$data->{$id} = null;
						{
							$_g = 0; $_g1 = $m->info->relations;
							while($_g < $_g1->length) {
								$i = $_g1[$_g];
								++$_g;
								$field = $i->key;
								$data->{$field} = 1;
								unset($i,$field);
							}
						}
						$m->manager->doInsert($data);
					} else {
						throw new HException("bbGrid.method:" . _hx_string_or_null($type));
					}
				}
			}
		}
		return new _hx_array(array());
	}
	public function bbModel($url) {
		$u = utils_XURLParser::parse($url);
		$m = hxqp_XLocalDB::model($u->desplit(null)->T);
		if($m === null) {
			throw new HException("bbModel: bad url " . _hx_string_or_null($url));
		}
		return $m->cols();
	}
	public function tryadd($x, $y) {
		throw new HException(1);
		return $x + $y;
	}
	static function mail($to, $subject, $body, $o) {
		$ret = "Message successfully sent";
		if(_hx_field($o, "username") === null) {
			$ret = hxqp_XRemote_1($body, $o, $ret, $subject, $to);
		} else {
			$from = $o->replyTo;
			$host = $o->smtp;
			$username = $o->username;
			$password = $o->password;
			
			$headers = array (
				'From' => $from,
	 			'To' => $to,
	   		'Subject' => $subject);
 			$smtp = Mail::factory('smtp',
	 			array ('host' => $host,
	   		'auth' => true,
	   		'username' => $username,
	   		'password' => $password));
			$mail = $smtp->send($to, $headers, $body);
 			if(PEAR::isError($mail)) $ret = $mail->getMessage();
			;
		}
		return $ret;
	}
	function __toString() { return 'hxqp.Remote'; }
}
function hxqp_XRemote_0(&$__hx__this, &$data, &$m, &$q, &$rowid, &$type, &$u, &$url) {
	{
		$s = $u->anchor;
		return str_replace(":1", $rowid, $s);
	}
}
function hxqp_XRemote_1(&$body, &$o, &$ret, &$subject, &$to) {
	if(php_XLib::mail($to, $subject, $body, null, null)) {
		return _hx_string_or_null($to) . ": mail was successfully accepted for delivery";
	} else {
		return "mail was failed";
	}
}
