<?php

class hxqp_XRemoteTest extends haxe_unit_XTestCase {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	public function testData() {
		haxe_XLog::trace(hxqp_XTProject::$manager, _hx_anonymous(array("fileName" => "Remote.hx", "lineNumber" => 187, "className" => "hxqp.RemoteTest", "methodName" => "testData")));
		new hxqp_XLocalDB();
		hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE 1 = 1", null);
		_hx_deref(new hxqp_XRemote())->bbGrid("PUT", "?T=TProject", "-1", _hx_anonymous(array("pid" => 1, "state" => "testData1")));
		$this->assertTrue(true, _hx_anonymous(array("fileName" => "Remote.hx", "lineNumber" => 196, "className" => "hxqp.RemoteTest", "methodName" => "testData")));
	}
	public function su($data) {
		try {
			return hxqp_XXLib::unserialize(hxqp_XXLib::serialize($data, null));
		}catch(Exception $__hx__e) {
			$_ex_ = ($__hx__e instanceof HException) ? $__hx__e->e : $__hx__e;
			$x = $_ex_;
			{
				haxe_XLog::trace($x, _hx_anonymous(array("fileName" => "Remote.hx", "lineNumber" => 182, "className" => "hxqp.RemoteTest", "methodName" => "su")));
			}
		}
		return $data;
	}
	function __toString() { return 'hxqp.RemoteTest'; }
}
