<?php

interface hxqp_XITag {
	function render($parent);
}
