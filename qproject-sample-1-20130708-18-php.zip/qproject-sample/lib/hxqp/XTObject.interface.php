<?php

interface hxqp_XTObject {
	function id();
}
