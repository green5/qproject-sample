<?php

class hxqp_XTProject extends sys_db_XObject implements hxqp_XTObject{
	public function __construct($name_, $group_ = null) {
		if(!php_XBoot::$skip_constructor) {
		parent::__construct();
		$this->name = $name_;
		$this->state = "start";
		$this->set_group(hxqp_XTGroup::group((($group_ === null) ? $name_ : $group_)));
	}}
	public function set_group($_v) {
		return hxqp_XTGroup::$manager->h__set($this, "group", "gid", $_v);
	}
	public function get_group() {
		return hxqp_XTGroup::$manager->h__get($this, "group", "gid", false);
	}
	public $state;
	public $name;
	public $pid;
	public function id() {
		return $this->pid;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function ui($t = null) {
		if($t === null) {
			return _hx_anonymous(array("pid" => "Pid", "name" => "Проект", "state" => "State", "group" => "Group"));
		}
		return _hx_anonymous(array("pid" => $t->pid, "name" => $t->name, "state" => $t->state, "group" => $t->get_group()->name));
	}
	static function project($name_, $group_ = null) {
		$t = hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE name = " . _hx_string_or_null(sys_db_XManager::quoteAny($name_)), null)->first();
		if($t === null) {
			_hx_deref(($t = new hxqp_XTProject($name_, $group_)))->insert();
		}
		return $t;
	}
	static $manager;
	static $__properties__ = array("set_group" => "set_group","get_group" => "get_group");
	function __toString() { return 'hxqp.TProject'; }
}
hxqp_XTProject::$__meta__ = _hx_anonymous(array("obj" => _hx_anonymous(array("rtti" => new _hx_array(array("oy4:namey8:TProjecty7:indexesahy9:relationsaoy4:lockfy4:propy5:groupy4:typey11:hxqp.TGroupy7:cascadefy6:isNullfy3:keyy3:gidghy7:hfieldsby3:pidoR0R14R10fy1:tjy17:sys.db.RecordType:0:0gy5:stateoR0R17R10fR15jR16:15:0gR12oR0R12R10fR15jR16:1:0gR0oR0R0R10fR15r8ghR11aR14hy6:fieldsar5r11r7r9hg"))))));
hxqp_XTProject::$manager = new sys_db_XManager(_hx_qtype("hxqp.TProject"));
