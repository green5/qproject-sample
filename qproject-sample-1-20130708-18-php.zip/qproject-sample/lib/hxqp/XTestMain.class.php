<?php

class hxqp_XTestMain extends haxe_unit_XTestCase {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	static function print_() { $args = func_get_args(); return call_user_func_array(self::$print_, $args); }
	static $print_;
	static function jprint($v) {
		$v = rtrim("" . XStd::string($v));
		call_user_func_array($__js__, array("print(v)"));
	}
	static function main() {
		haxe_XLog::$trace = (isset(hxqp_XXLib::$xtrace) ? hxqp_XXLib::$xtrace: array("hxqp_XXLib", "xtrace"));
		$r = new haxe_unit_XTestRunner();
		$r->add(new hxqp_XXLibTest());
		$r->add(new utils_XTest());
		$r->add(new hxqp_XLocalDBTest());
		$r->add(new hxqp_XRemoteTest());
		$r->add(new hxqp_XMainTest());
		$r->run();
	}
	function __toString() { return 'hxqp.TestMain'; }
}
hxqp_XTestMain::$print_ = haxe_unit_XTestRunner::$hprint;
