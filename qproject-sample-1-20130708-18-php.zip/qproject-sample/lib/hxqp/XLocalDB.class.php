<?php

class hxqp_XLocalDB {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		if(hxqp_XLocalDB::$local_ === null) {
			hxqp_XLocalDB::$local_ = hxqp__Data_XSql_Impl_::sdb("sqlite:/home/green/public_html/wp/wp-content/plugins/qproject-sample/data/local.db");
			sys_db_XManager::set_cnx(hxqp_XLocalDB::$local_->connection());
			sys_db_XManager::initialize();
		}
	}}
	public function testData() {
		hxqp_XTGroup::group("Translators");
		hxqp_XTGroup::group("Programmers");
		hxqp_XTUser::user("Igor", "Translators");
		hxqp_XTUser::user("Ivan", "Translators");
		hxqp_XTUser::user("Rustem", "Programmers");
		hxqp_XTProject::project("Zero", null);
		hxqp_XTProject::project("Second", "Translators");
		hxqp_XTProject::project("Third", "Translators");
		hxqp_XTProject::project("Zero", "Programmers");
		hxqp_XTLink::link("Zero", "Rustem");
		hxqp_XTLink::link("Second", "Ivan");
		hxqp_XTLink::link("Second", "Igor");
		hxqp_XTLink::link("Third", "Ivan");
		hxqp_XTLink::link("Third", "Ivan");
		return $this;
	}
	public function create() {
		if(!sys_db_XTableCreate::exists(hxqp_XTGroup::$manager)) {
			sys_db_XTableCreate::create(hxqp_XTGroup::$manager, null);
		}
		if(!sys_db_XTableCreate::exists(hxqp_XTUser::$manager)) {
			sys_db_XTableCreate::create(hxqp_XTUser::$manager, null);
		}
		if(!sys_db_XTableCreate::exists(hxqp_XTProject::$manager)) {
			sys_db_XTableCreate::create(hxqp_XTProject::$manager, null);
		}
		if(!sys_db_XTableCreate::exists(hxqp_XTLink::$manager)) {
			sys_db_XTableCreate::create(hxqp_XTLink::$manager, null);
		}
		return $this;
	}
	public function drop() {
		hxqp_XLocalDB::$local_->query("drop table if exists TLink", null, null, null);
		hxqp_XLocalDB::$local_->query("drop table if exists TProject", null, null, null);
		hxqp_XLocalDB::$local_->query("drop table if exists TUser", null, null, null);
		hxqp_XLocalDB::$local_->query("drop table if exists TGroup", null, null, null);
		return $this;
	}
	public function data() {
		return hxqp_XLocalDB::$local_;
	}
	static function model($table) {
		new hxqp_XLocalDB();
		$c = XType::resolveClass("hxqp." . _hx_string_or_null($table));
		if($c === null) {
			return null;
		}
		$manager = XReflect::field($c, "manager");
		if($manager === null) {
			return null;
		}
		$ui = XReflect::field($c, "ui");
		$info = $manager->dbInfos();
		return _hx_anonymous(array("manager" => $manager, "info" => $info, "cols" => hxqp_XLocalDB_0($c, $info, $manager, $table, $ui), "ui" => hxqp_XLocalDB_1($c, $info, $manager, $table, $ui)));
	}
	static $local_ = null;
	function __toString() { return 'hxqp.LocalDB'; }
}
function hxqp_XLocalDB_0(&$c, &$info, &$manager, &$table, &$ui) {
	if($ui === null) {
		return array(new _hx_lambda(array(&$c, &$info, &$manager, &$table, &$ui), "hxqp_XLocalDB_2"), 'execute');
	} else {
		return $ui;
	}
}
function hxqp_XLocalDB_1(&$c, &$info, &$manager, &$table, &$ui) {
	if($ui === null) {
		return array(new _hx_lambda(array(&$c, &$info, &$manager, &$table, &$ui), "hxqp_XLocalDB_3"), 'execute');
	} else {
		return $ui;
	}
}
function hxqp_XLocalDB_2(&$c, &$info, &$manager, &$table, &$ui) {
	{
		$ret = _hx_anonymous(array());
		{
			$_g = 0; $_g1 = $info->fields;
			while($_g < $_g1->length) {
				$i = $_g1[$_g];
				++$_g;
				$ret->{$i->name} = $i->name;
				unset($i);
			}
		}
		return $ret;
	}
}
function hxqp_XLocalDB_3(&$c, &$info, &$manager, &$table, &$ui, $a) {
	{
		$ret = _hx_anonymous(array());
		{
			$_g = 0; $_g1 = $info->fields;
			while($_g < $_g1->length) {
				$i = $_g1[$_g];
				++$_g;
				$ret->{$i->name} = XReflect::field($a, $i->name);
				unset($i);
			}
		}
		return $ret;
	}
}
