<?php

class hxqp_data_XPDO2 implements sys_db_XConnection, hxqp_XData{
	public function __construct($dsn = null, $user = null, $password = null, $options = null) {
		if(!php_XBoot::$skip_constructor) {
		if($dsn === null) {
			$dsn = "sqlite:/home/green/public_html/wp/wp-content/plugins/qproject-sample/data/local.db";
		}
		$this->cnx = php_db_XPDO::open($dsn, $user, $password, $options);
		$this->pdo = XReflect::field($this->cnx, "pdo");
		$this->pdo->setAttribute(3, 2);
	}}
	public function nexecute($sql, $arg, $style, $nrow) {
		$ret = new _hx_array(array());
		if($style === -1) {
			$style = 2;
		}
		try {
			$stm = $this->pdo->prepare($sql, array());
			if($stm === null) {
				throw new HException(_hx_string_rec(1, "") . " " . _hx_string_or_null($this->error()));
			}
			if($arg !== null) {
				$arg = $arg->a;
				if(_hx_index_of($sql, ":1", null) > 0) {
					$stm->bindParam(":1", $arg[0], hxqp_data_XPDO2::pdoType($arg[0]), null, null);
				}
				if(_hx_index_of($sql, ":2", null) > 0) {
					$stm->bindParam(":2", $arg[1], hxqp_data_XPDO2::pdoType($arg[1]), null, null);
				}
				if(_hx_index_of($sql, ":3", null) > 0) {
					$stm->bindParam(":3", $arg[2], hxqp_data_XPDO2::pdoType($arg[2]), null, null);
				}
				if(_hx_index_of($sql, ":4", null) > 0) {
					$stm->bindParam(":4", $arg[3], hxqp_data_XPDO2::pdoType($arg[3]), null, null);
				}
				if(_hx_index_of($sql, ":5", null) > 0) {
					$stm->bindParam(":5", $arg[4], hxqp_data_XPDO2::pdoType($arg[4]), null, null);
				}
				if(_hx_index_of($sql, ":6", null) > 0) {
					$stm->bindParam(":6", $arg[5], hxqp_data_XPDO2::pdoType($arg[5]), null, null);
				}
				if(_hx_index_of($sql, ":7", null) > 0) {
					$stm->bindParam(":7", $arg[6], hxqp_data_XPDO2::pdoType($arg[6]), null, null);
				}
				if(_hx_index_of($sql, ":8", null) > 0) {
					$stm->bindParam(":8", $arg[7], hxqp_data_XPDO2::pdoType($arg[7]), null, null);
				}
				if(_hx_index_of($sql, ":9", null) > 0) {
					$stm->bindParam(":9", $arg[8], hxqp_data_XPDO2::pdoType($arg[8]), null, null);
				}
				if(($stm === false)) {
					throw new HException(_hx_string_rec(1, "") . " " . _hx_string_or_null($this->error()));
				}
			}
			$ret1 = $stm->execute(array());
			if(($ret1 === false)) {
				throw new HException(_hx_string_rec(1, "") . " " . _hx_string_or_null($this->error()));
			}
			if($nrow === -1) {
				$ret1 = $stm->fetchAll(3);
				if(($ret1 === false)) {
					throw new HException(_hx_string_rec(1, "") . " " . _hx_string_or_null($this->error()));
				}
				if(is_array($ret1)) {
					$ret1 = hxqp_data_XPDO2_0($this, $arg, $nrow, $ret, $ret1, $sql, $stm, $style);
				}
				return $ret1;
			}
			$ret1 = new _hx_array(array());
			while(true) {
				$row = $stm->fetch($style, null, null);
				if(($row === false)) {
					break;
				}
				if($style !== 3) {
					$row = _hx_anonymous($row);
				}
				$ret1->push($row);
				unset($row);
			}
			return $ret1;
		}catch(Exception $__hx__e) {
			$_ex_ = ($__hx__e instanceof HException) ? $__hx__e->e : $__hx__e;
			$e = $_ex_;
			{
				throw new HException($e);
			}
		}
	}
	public function error() {
		return _hx_array_get($this->pdo->errorInfo(), 2);
	}
	public function query($sql, $arg = null, $style = null, $nrow = null) {
		if($nrow === null) {
			$nrow = -1;
		}
		if($style === null) {
			$style = -1;
		}
		return $this->nexecute($sql, $arg, $style, $nrow);
	}
	public function x1($sql, $arg = null, $style = null) {
		if($style === null) {
			$style = -1;
		}
		return $this->nexecute($sql, $arg, $style, 1);
	}
	public function x0($sql, $arg = null, $style = null) {
		if($style === null) {
			$style = -1;
		}
		return $this->nexecute($sql, $arg, $style, 0);
	}
	public function connection() {
		return $this->cnx;
	}
	public $pdo;
	public $cnx;
	public function rollback() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.rollback is null");
		}
		$this->cnx->rollback();
		return;
	}
	public function commit() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.commit is null");
		}
		$this->cnx->commit();
		return;
	}
	public function startTransaction() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.startTransaction is null");
		}
		$this->cnx->startTransaction();
		return;
	}
	public function dbName() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.dbName is null");
		}
		return $this->cnx->dbName();
	}
	public function lastInsertId() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.lastInsertId is null");
		}
		return $this->cnx->lastInsertId();
	}
	public function addValue($s, $v) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.addValue is null");
		}
		$this->cnx->addValue($s, $v);
		return;
	}
	public function quote($s) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.quote is null");
		}
		return $this->cnx->quote($s);
	}
	public function escape($s) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.escape is null");
		}
		return $this->cnx->escape($s);
	}
	public function close() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.close is null");
		}
		$this->cnx->close();
		return;
	}
	public function request($s) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.request is null");
		}
		return $this->cnx->request($s);
	}
	public $__dynamics = array();
	public function __get($n) {
		if(isset($this->__dynamics[$n]))
			return $this->__dynamics[$n];
	}
	public function __set($n, $v) {
		$this->__dynamics[$n] = $v;
	}
	public function __call($n, $a) {
		if(isset($this->__dynamics[$n]) && is_callable($this->__dynamics[$n]))
			return call_user_func_array($this->__dynamics[$n], $a);
		if('toString' == $n)
			return $this->__toString();
		throw new HException("Unable to call <".$n.">");
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function styles() {
		return new _hx_array(array(2, 4, 3));
	}
	static function pdoType($a) {
		$t = hxqp_data_XPDO2_1($a);
		if($t === "string") {
			return PDO::PARAM_STR;
		}
		if($t === "integr") {
			return PDO::PARAM_INT;
		}
		return PDO::PARAM_STR;
	}
	function __toString() { return 'hxqp.data.PDO2'; }
}
hxqp_data_XPDO2::$__meta__ = _hx_anonymous(array("fields" => _hx_anonymous(array("cnx" => _hx_anonymous(array("import" => null))))));
function hxqp_data_XPDO2_0(&$__hx__this, &$arg, &$nrow, &$ret, &$ret1, &$sql, &$stm, &$style) {
	{
		$a = $ret1;
		return new _hx_array($a);
	}
}
function hxqp_data_XPDO2_1(&$a) {
	{
		$t1 = gettype($a);
		if($t1 === "object") {
			$t1 = get_class($a);
		}
		return $t1;
	}
}
