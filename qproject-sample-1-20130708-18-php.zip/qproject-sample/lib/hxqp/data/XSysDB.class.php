<?php

class hxqp_data_XSysDB implements sys_db_XConnection, hxqp_XData{
	public function __construct($dsn = null, $user = null, $password = null, $options = null) {
		if(!php_XBoot::$skip_constructor) {
		if($dsn === null) {
			$dsn = "sqlite:/home/green/public_html/wp/wp-content/plugins/qproject-sample/data/local.db";
		}
		$tt = _hx_explode(":", $dsn);
		$t1 = $tt->shift();
		$t2 = $tt->join(":");
		if($t1 === "sys.sqlite") {
			$this->cnx = sys_db_XSqlite::open($t2);
		} else {
			if($t1 === "sys.mysql") {
				$this->cnx = sys_db_XMysql::connect(_hx_anonymous(array("host" => "localhost", "user" => $user, "pass" => $password, "database" => $t2)));
			} else {
				$this->cnx = php_db_XPDO::open($dsn, $user, $password, $options);
			}
		}
	}}
	public function query($sql, $arg = null, $style = null, $nrow = null) {
		if($nrow === null) {
			$nrow = -1;
		}
		if($style === null) {
			$style = -1;
		}
		$t = $this->cnx->request($sql);
		$l = $t->results();
		$ret = new _hx_array(array());
		if(null == $l) throw new HException('null iterable');
		$__hx__it = $l->iterator();
		while($__hx__it->hasNext()) {
			$i = $__hx__it->next();
			$ret->push($i);
		}
		return $ret;
	}
	public function connection() {
		return $this;
	}
	public $cnx;
	public function rollback() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.rollback is null");
		}
		$this->cnx->rollback();
		return;
	}
	public function commit() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.commit is null");
		}
		$this->cnx->commit();
		return;
	}
	public function startTransaction() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.startTransaction is null");
		}
		$this->cnx->startTransaction();
		return;
	}
	public function dbName() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.dbName is null");
		}
		return $this->cnx->dbName();
	}
	public function lastInsertId() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.lastInsertId is null");
		}
		return $this->cnx->lastInsertId();
	}
	public function addValue($s, $v) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.addValue is null");
		}
		$this->cnx->addValue($s, $v);
		return;
	}
	public function quote($s) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.quote is null");
		}
		return $this->cnx->quote($s);
	}
	public function escape($s) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.escape is null");
		}
		return $this->cnx->escape($s);
	}
	public function close() {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.close is null");
		}
		$this->cnx->close();
		return;
	}
	public function request($s) {
		if($this->cnx === null) {
			throw new HException("TFun:cnx.request is null");
		}
		return $this->cnx->request($s);
	}
	public $__dynamics = array();
	public function __get($n) {
		if(isset($this->__dynamics[$n]))
			return $this->__dynamics[$n];
	}
	public function __set($n, $v) {
		$this->__dynamics[$n] = $v;
	}
	public function __call($n, $a) {
		if(isset($this->__dynamics[$n]) && is_callable($this->__dynamics[$n]))
			return call_user_func_array($this->__dynamics[$n], $a);
		if('toString' == $n)
			return $this->__toString();
		throw new HException("Unable to call <".$n.">");
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	function __toString() { return 'hxqp.data.SysDB'; }
}
hxqp_data_XSysDB::$__meta__ = _hx_anonymous(array("fields" => _hx_anonymous(array("cnx" => _hx_anonymous(array("import" => null))))));
