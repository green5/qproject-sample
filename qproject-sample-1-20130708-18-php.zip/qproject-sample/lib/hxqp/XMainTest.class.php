<?php

class hxqp_XMainTest extends haxe_unit_XTestCase {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	public function testSDB() {
		$q = _hx_deref(new hxqp_XLocalDB())->data()->query("select pid id,name,gid 'group',state from TProject limit 2", null, null, null);
		$this->assertEquals(2, _hx_len($q), _hx_anonymous(array("fileName" => "Main.hx", "lineNumber" => 170, "className" => "hxqp.MainTest", "methodName" => "testSDB")));
	}
	public function testPDO() {
		$x = hxqp__Data_XSql_Impl_::pdo("sqlite:/home/green/public_html/wp/wp-content/plugins/qproject-sample/data/local.db");
		$q = $x->query("select pid id,name,gid 'group',state from TProject limit 2", null, null, null);
		$this->assertEquals(2, _hx_len($q), _hx_anonymous(array("fileName" => "Main.hx", "lineNumber" => 164, "className" => "hxqp.MainTest", "methodName" => "testPDO")));
	}
	public function testTMAIN() {
		$c = new hxqp_cms_XWP();
		hxqp_XMain::makeOptionPage($c->options());
		$c->options()->render(hxqp_XProject::root());
		$str = hxqp_XProject::root()->dump(null);
		hxqp_XXLib::xtrace("Done", _hx_anonymous(array("fileName" => "Main.hx", "lineNumber" => 156, "className" => "hxqp.MainTest", "methodName" => "testTMAIN")));
		$this->assertEquals(1, 1, _hx_anonymous(array("fileName" => "Main.hx", "lineNumber" => 157, "className" => "hxqp.MainTest", "methodName" => "testTMAIN")));
	}
	function __toString() { return 'hxqp.MainTest'; }
}
