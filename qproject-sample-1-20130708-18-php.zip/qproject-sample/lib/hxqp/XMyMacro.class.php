<?php

class hxqp_XMyMacro {
	public function __construct(){}
	function __toString() { return 'hxqp.MyMacro'; }
}
