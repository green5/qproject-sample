<?php

interface hxqp_cms_XCMS {
	function remote();
	function hooks();
	function options();
}
