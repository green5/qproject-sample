<?php

class hxqp_cms_XOption extends hxqp_XOption {
	public function __construct($parent, $name, $title, $attr, $render = null) { if(!php_XBoot::$skip_constructor) {
		parent::__construct($parent,$name,$title,$attr,$render);
	}}
	public function value() {
		$x = get_option(_hx_string_or_null($this->parent_->name1()) . "_options");
		return hxqp_XXLib::isget($this->attr_->value, $x, $this->name_);
	}
	static function _new($parent, $name, $title, $attr, $render = null) { return call_user_func_array(self::$_new, array($parent, $name, $title, $attr, $render)); }
	public static $_new = null;
	function __toString() { return 'hxqp.cms.Option'; }
}
hxqp_cms_XOption::$_new = array(new _hx_lambda(array(), "hxqp_cms_XOption_0"), 'execute');
function hxqp_cms_XOption_0($parent, $name, $title, $attr, $render) {
	{
		return new hxqp_cms_XOption($parent, $name, $title, $attr, $render);
	}
}
