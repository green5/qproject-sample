<?php

class hxqp_cms__WP_XRemote {
	public function __construct($options) {
		if(!php_XBoot::$skip_constructor) {
		$this->options_ = $options;
	}}
	public function mail($to, $subject, $body) {
		$o = _hx_anonymous(array("from" => $this->options_->get("replyTo"), "host" => $this->options_->get("smtp"), "username" => $this->options_->get("user"), "password" => $this->options_->get("password")));
		return hxqp_XRemote::mail($to, $subject, $body, $o);
	}
	public $options_;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return 'hxqp.cms._WP.Remote'; }
}
