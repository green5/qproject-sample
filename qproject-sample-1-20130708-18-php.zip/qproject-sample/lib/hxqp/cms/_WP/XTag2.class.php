<?php

class hxqp_cms__WP_XTag2 {
	public function __construct(){}
	static function includeCSS($Tag, $path) {
		$h = hxqp_cms__WP_XTag2_0($Tag, $path);
		if(wp_style_is($h)) {
			return;
		}
		wp_deregister_style($h);
		wp_register_style($h, $path);
		wp_enqueue_style($h);
	}
	static function includeJS($Tag, $path) {
		$h = hxqp_cms__WP_XTag2_1($Tag, $path);
		if(wp_script_is($h, "enqueued")) {
			return;
		}
		wp_enqueue_script($h, $path);
	}
	function __toString() { return 'hxqp.cms._WP.Tag2'; }
}
function hxqp_cms__WP_XTag2_0(&$Tag, &$path) {
	{
		$s = basename($path, ".css");
		return str_replace(".", "-", $s);
	}
}
function hxqp_cms__WP_XTag2_1(&$Tag, &$path) {
	{
		$s = basename($path, ".js");
		return str_replace(".", "-", $s);
	}
}
