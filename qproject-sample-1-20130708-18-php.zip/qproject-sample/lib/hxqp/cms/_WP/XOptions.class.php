<?php

class hxqp_cms__WP_XOptions extends hxqp_XOptions implements hxqp_XITag{
	public function __construct() {
		if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	public function render($page) {
		$page->hinclude("/ext/jquery.js");
		{
			$_g = 0; $_g1 = $this->sections_;
			while($_g < $_g1->length) {
				$s = $_g1[$_g];
				++$_g;
				add_settings_section($s->title_, $s->title_, null, $this->page_);
				$__hx__it = call_user_func((hxqp_cms__WP_XOptions_0($this, $_g, $_g1, $o, $page, $s)));
				while($__hx__it->hasNext()) {
					$o = $__hx__it->next();
					add_settings_field($o->name_, $o->title_, hxqp_cms__WP_XOptions_1($this, $_g, $_g1, $o, $page, $s), $this->page_, $s->title_);
				}
				unset($s);
			}
		}
		$page->tag("div", _hx_anonymous(array("id" => _hx_string_or_null($this->name1()) . "-tabs")), null)->tabs($this->sections_->iterator(), (isset($this->hrender) ? $this->hrender: array($this, "hrender")));
	}
	public function hrender($parent, $tab) {
		$section = $tab;
		if($section !== null && $section->title_ === "Options") {
			$form = $parent->tag("form", _hx_anonymous(array("action" => "options.php", "method" => "post")), null);
			$form->html(hxqp_XXLib::ob_vcall("settings_fields", new _hx_array(array(_hx_string_or_null($this->name1()) . "_options"))));
			$tab->render($form);
			$form->tag("br", null, null)->input("submit", _hx_anonymous(array("name" => "Submit", "value" => "Save Changes")));
		} else {
			$tab->render($parent);
		}
	}
	public function validate($input) {
		$name = null;
		$value = null;
		if(is_array($input)) foreach($input as $name=>$value){
		$o = $this->getOption($name);
		if($o !== null) {
			$nvalue = $o->validate($value);
			if($nvalue !== null) {
				$input[$name] = $nvalue;
			}
		}
		}
		return $input;
	}
	public $page_ = "qproject-sample";
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return 'hxqp.cms._WP.Options'; }
}
function hxqp_cms__WP_XOptions_0(&$__hx__this, &$_g, &$_g1, &$o, &$page, &$s) {
	{
		$_e = $s->options_;
		return array(new _hx_lambda(array(&$_e, &$_g, &$_g1, &$o, &$page, &$s), "hxqp_cms__WP_XOptions_2"), 'execute');
	}
}
function hxqp_cms__WP_XOptions_1(&$__hx__this, &$_g, &$_g1, &$o, &$page, &$s) {
	{
		$f = (isset($o->{"print"}) ? $o->{"print"}: array($o, "hprint"));
		return array(new _hx_lambda(array(&$_g, &$_g1, &$f, &$o, &$page, &$s), "hxqp_cms__WP_XOptions_3"), 'execute');
	}
}
function hxqp_cms__WP_XOptions_2(&$_e, &$_g, &$_g1, &$o, &$page, &$s) {
	{
		return $_e->iterator();
	}
}
function hxqp_cms__WP_XOptions_3(&$_g, &$_g1, &$f, &$o, &$page, &$s) {
	{
		call_user_func($f);
		return;
	}
}
