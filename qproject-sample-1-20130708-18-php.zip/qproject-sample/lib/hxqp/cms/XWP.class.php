<?php

class hxqp_cms_XWP implements hxqp_cms_XCMS{
	public function __construct() {
		if(!php_XBoot::$skip_constructor) {
		hxqp_XXLib::$vcallException_ = false;
		$this->options_ = new hxqp_cms__WP_XOptions();
		$this->options_->section("Options", null, null)->option("smtp", _hx_anonymous(array("value" => "localhost:25", "title" => "mail server[:port=25]")), null)->option("user", _hx_anonymous(array("value" => "www-data", "title" => "optional")), null)->option("password", _hx_anonymous(array("type" => "password")), null)->option("replyTo", _hx_anonymous(array("value" => "root@localhost", "title" => "your email address")), array(new _hx_lambda(array(), "hxqp_cms_XWP_0"), 'execute'))->option("localDSN", _hx_anonymous(array("value" => "sqlite:/home/green/public_html/wp/wp-content/plugins/qproject-sample/data/local.db")), null);
	}}
	public function print_page() {
		hxqp_XProject::root()->hprint();
	}
	public function admin_menu() {
		add_options_page($this->name_, $this->name_, "manage_options", $this->page_, hxqp_cms_XWP_1($this));
		hxqp_XTag::$includeJS = (isset(hxqp_cms__WP_XTag2::$includeJS) ? hxqp_cms__WP_XTag2::$includeJS: array("hxqp_cms__WP_XTag2", "includeJS"));
		hxqp_XTag::$includeCSS = (isset(hxqp_cms__WP_XTag2::$includeCSS) ? hxqp_cms__WP_XTag2::$includeCSS: array("hxqp_cms__WP_XTag2", "includeCSS"));
		$this->options_->render(hxqp_XProject::root());
		hxqp_XProject::root()->hinclude("/index.js");
	}
	public function plugin_row_meta($links) {
		if(isset($links[2]) && _hx_string_call($links[2], "indexOf", array("qproject-sample")) > 0) {
			array_push($links, "<a href=\"admin.php?page=" . _hx_string_or_null($this->page_) . "\">Settings</a>");
		}
		return $links;
	}
	public function admin_init() {
		register_setting(_hx_string_or_null($this->name_) . "_options", _hx_string_or_null($this->name_) . "_options", hxqp_XXLib::aa(new _hx_array(array($this->options_, "validate"))));
	}
	public function options() {
		return $this->options_;
	}
	public function hooks() {
		if(!function_exists("plugins_url")) {
			return;
		}
		hxqp_XProject::setURL(plugins_url($this->page_));
		
 		global $wp_filter;
		if(isset($wp_filter)) foreach($wp_filter as $a=>$x) 
			if(method_exists($this,$a)) add_filter($a,array($this,$a));
		;
		add_filter("plugin_row_meta", (isset($this->plugin_row_meta) ? $this->plugin_row_meta: array($this, "plugin_row_meta")));
	}
	public function remote() {
		return new hxqp_cms__WP_XRemote($this->options_);
	}
	public $name_ = "qproject_sample";
	public $page_ = "qproject-sample";
	public $options_;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return 'hxqp.cms.WP'; }
}
hxqp_XOption::$_new = hxqp_cms_XOption::$_new;
function hxqp_cms_XWP_0($paren) {
	{
		$paren->tag("input", _hx_anonymous(array("type" => "button", "value" => "TestMail", "onclick" => "hxqp.Remote.mail()")), null);
	}
}
function hxqp_cms_XWP_1(&$__hx__this) {
	{
		$f = (isset($__hx__this->print_page) ? $__hx__this->print_page: array($__hx__this, "print_page"));
		return array(new _hx_lambda(array(&$f), "hxqp_cms_XWP_2"), 'execute');
	}
}
function hxqp_cms_XWP_2(&$f) {
	{
		call_user_func($f);
		return;
	}
}
