<?php

interface hxqp_XTagIterator {
	function next($parent);
	function hasNext();
}
