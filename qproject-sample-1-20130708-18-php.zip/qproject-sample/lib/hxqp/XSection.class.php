<?php

class hxqp_XSection implements hxqp_XITag{
	public function __construct($parent, $title, $render = null, $href = null) {
		if(!php_XBoot::$skip_constructor) {
		$this->parent_ = $parent;
		$this->options_ = new haxe_ds_XStringMap();
		$this->title_ = $title;
		$this->render_ = $render;
		$this->href_ = $href;
	}}
	public function render($parent) {
		$tab = $parent->tag("table", _hx_anonymous(array("class" => "form-table")), null);
		XLambda::iter($this->options_, array(new _hx_lambda(array(&$parent, &$tab), "hxqp_XSection_0"), 'execute'));
		if($this->render_) {
			$this->render_($parent);
		}
	}
	public function option($name, $attr = null, $render = null) {
		$title = ucfirst($name);
		$name = _hx_string_or_null($this->parent_->name1()) . "_" . _hx_string_or_null($name);
		if($attr === null) {
			$attr = _hx_anonymous(array());
		}
		{
			$v = hxqp_XOption::_new($this->parent_, $name, $title, $attr, $render);
			$this->options_->set($name, $v);
			$v;
		}
		return $this;
	}
	public $href_;
	public $render_;
	public $title_;
	public $options_;
	public $parent_;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return 'hxqp.Section'; }
}
function hxqp_XSection_0(&$parent, &$tab, $o) {
	{
		$tr = $tab->tag("tr", _hx_anonymous(array("valign" => "top")), null)->tag("th", _hx_anonymous(array("scope" => "row")), $o->title_);
		$o->render($tr->tag("td", null, null));
	}
}
