<?php

class hxqp_XTag extends hxqp_XTagCommon {
	public function __construct($parent, $tag, $attr = null, $text = null, $from = null) {
		if(!php_XBoot::$skip_constructor) {
		$this->parent_ = $parent;
		$this->tag_ = $tag;
		$this->attr_ = (($attr === null) ? _hx_anonymous(array()) : $attr);
		$this->from_ = (($from === null) ? hxqp_XXLib::callFrom(3) : $from);
		$this->text_ = $text;
		$this->children_ = new _hx_array(array());
	}}
	public function _talert($title = null) {
		if($title === null) {
			$title = "Dialog";
		}
		return $this->parent_->talert($title);
	}
	public function talert($title = null) {
		if($title === null) {
			$title = "Dialog";
		}
		$this->hinclude("/ext/jquery.js");
		$this->hinclude("/ext/ui/jquery-ui.js");
		$this->hinclude("/ext/ui/jquery.ui.dialog.js");
		return $this->top()->utag("div", _hx_anonymous(array("id" => "hxqp-Tag-talert", "title" => $title)), null);
	}
	public function bbForm($model) {
		$this->hinclude("/ext/bootstrap/bootstrap.css");
		$this->hinclude("/ext/jquery.js");
		$this->hinclude("/ext/ui/jquery-ui.js");
		$this->hinclude("/ext/ui/jquery.ui.dialog.js");
		$f = hxqp_XTag_0($this, $model);
		$t = $f->tag("table", _hx_anonymous(array("c" => "container span6")), null);
		{
			$_g = 0;
			while($_g < $model->length) {
				$a = $model[$_g];
				++$_g;
				$t->tag("tr", _hx_anonymous(array("c" => "row")), null)->tag("td", _hx_anonymous(array("c" => "span1")), $a->title)->_tag("td", null, null)->input("text", _hx_anonymous(array("name" => $a->name)));
				unset($a);
			}
		}
		return $f->id();
	}
	public function _bbGrid($url, $v = null) {
		return $this->parent_->bbGrid($url, $v);
	}
	public function bbGrid($url, $v = null) {
		$this->hinclude("/ext/jquery.js");
		$this->hinclude("/ext/bootstrap/bootstrap.css");
		$this->hinclude("/ext/bootstrap/bootstrap-responsive.css");
		$this->hinclude("/ext/bootstrap/bootstrap.js");
		$this->hinclude("/ext/underscore.js");
		$this->hinclude("/ext/backbone.js");
		$this->hinclude("/ext/bbGrid.css");
		$this->hinclude("/ext/bbGrid.js");
		$level = 0;
		if(_hx_field($this->attr_, "level_") !== null) {
			$level++;
		}
		{
			$_g = 0; $_g1 = $this->parents();
			while($_g < $_g1->length) {
				$i = $_g1[$_g];
				++$_g;
				if(_hx_field($i->attr_, "level_") === null) {
					break;
				}
				$level++;
				unset($i);
			}
		}
		$model = $this->bbModel($url, $level);
		$v = hxqp_XXLib::extend(_hx_anonymous(array("colModel" => $model, "loadDynamic" => true, "enableSearch" => true, "rows" => 5, "lang" => "ru", "multiselect" => true, "useRemote_" => true, "url_" => hxqp_XProject::URL($url), "id_" => _hx_array_get($model, 0)->name)), $v);
		$t = null;
		if($level > 0) {
			$t = hxqp_XTag_1($this, $level, $model, $t, $url, $v);
			$this->attr_->subid = $t->attr_->id;
		} else {
			$t = hxqp_XTag_2($this, $level, $model, $t, $url, $v);
			{
				$t1 = $t->tag("div", _hx_anonymous(array("c" => "row")), null);
				$t1->id();
				$t1;
			}
			$t->tag("script", _hx_anonymous(array()), hxqp_XXLib::sprintf("\$(document).ready(function(){hxqp.Tag.bbGrid(\$('#'+%s)[0],null,-1)})", hxqp_XTag_3($this, $level, $model, $t, $url, $v), null, null, null, null, null, null, null, null));
			$t->attr_->formid = $this->bbForm($model);
		}
		return $t;
	}
	public function bbModel($url, $level) {
		$mm = _hx_deref(new hxqp_XRemote())->bbModel($url);
		$t = new _hx_array(array());
		{
			$_g = 0; $_g1 = XReflect::fields($mm);
			while($_g < $_g1->length) {
				$m = $_g1[$_g];
				++$_g;
				$title = hxqp_XXLib::ucfirst($m);
				$t->push(_hx_anonymous(array("title" => $title, "name" => $m, "index" => true, "filter" => true, "filterType" => "input")));
				unset($title,$m);
			}
		}
		return $t;
	}
	public function _jqGrid($src, $id = null) {
		return $this->parent_->jqGrid($src, $id);
	}
	public function jqGrid($src, $id = null) {
		$this->hinclude("/ext/jquery.js");
		$this->hinclude("/index.js");
		$this->hinclude("/ext/jqGrid/css/ui.jqgrid.css");
		$this->hinclude("/ext/jqGrid/jquery.jqGrid.js");
		$t = $this->tag("table", _hx_anonymous(array("id" => "list", "c" => "scroll")), null);
		$t->tag("div", _hx_anonymous(array("id" => XStd::string($t->attr_->id) . "-pager", "c" => "scroll", "style" => "text-align:center")), null);
		$this->tag("script", _hx_anonymous(array()), hxqp_XXLib::sprintf("\$(document).ready(function(){hxqp.Tag.jqGrid('%s','%s')})", $src, $t->attr_->id, null, null, null, null, null, null, null));
		return $t;
	}
	public function _tabs($hh, $hrender = null) {
		return $this->parent_->tabs($hh, $hrender);
	}
	public function tabs($hh, $hrender = null) {
		$ul = $this->tag("ul", null, null);
		$__hx__it = $hh;
		while($__hx__it->hasNext()) {
			$h = $__hx__it->next();
			$id = $this->nextid();
			$href = hxqp_XXLib::isget(null, $h, "href_");
			$a = $ul->tag("li", null, null)->tag("a", null, null);
			$a->attr_->href = hxqp_XTag_4($this, $a, $h, $hh, $href, $hrender, $id, $ul);
			$a->text_ = XReflect::field($h, "title_");
			if($a->text_ === null) {
				$a->text_ = "Title";
			}
			if($hrender === null) {
				$h->render($this->tag("div", _hx_anonymous(array("id" => $id)), null));
			} else {
				call_user_func_array($hrender, array($this->tag("div", _hx_anonymous(array("id" => $id)), null), $h));
			}
			unset($id,$href,$a);
		}
		$this->hinclude("/ext/jquery.js");
		$this->hinclude("/ext/themes/base/jquery.ui.all.css");
		$this->hinclude("/ext/ui/jquery.ui.core.js");
		$this->hinclude("/ext/ui/jquery.ui.widget.js");
		$this->hinclude("/ext/ui/jquery.ui.tabs.js");
		$this->top()->tag("script", _hx_anonymous(array()), hxqp_XXLib::sprintf("\$(function(){hxqp.Tag.tabsReady('#%s')})", $this->id(), null, null, null, null, null, null, null, null));
		return $ul;
	}
	public function _span($attr = null, $text = null) {
		return hxqp_XTag_5($this, $attr, $text);
	}
	public function span($attr = null, $text = null) {
		$t = $this->tag("span", $attr, $text);
		$t->id();
		return $t;
	}
	public function _div($attr = null, $text = null) {
		return hxqp_XTag_6($this, $attr, $text);
	}
	public function div($attr = null, $text = null) {
		$t = $this->tag("div", $attr, $text);
		$t->id();
		return $t;
	}
	public function _input($type, $attr) {
		return $this->parent_->input($type, $attr);
	}
	public function input($type, $attr) {
		if(_hx_field($this->attr_, "type") === null) {
			$this->attr_->type = "text";
		}
		switch($type) {
		case "text":{
			$attr->type = $type;
			$attr->{"class"} = "regular-text";
			$attr->value = XStringTools::htmlEscape($attr->value, null);
			return $this->tag("input", $attr, null);
		}break;
		}
		$attr->type = $type;
		$attr->value = XStringTools::htmlEscape($attr->value, null);
		return $this->tag("input", $attr, null);
	}
	public function hinclude($path) {
		$path = hxqp_XProject::URL($path);
		if(_hx_index_of($path, ".js", null) > 0) {
			$path = $this->fixPath($path);
			hxqp_XTag::includeJS($this->top(), $path);
			return;
		}
		if(_hx_index_of($path, ".css", null) > 0) {
			hxqp_XTag::includeCSS($this->top(), $path);
			return;
		}
		haxe_XLog::trace("include: " . _hx_string_or_null($path), _hx_anonymous(array("fileName" => "Tag.hx", "lineNumber" => 243, "className" => "hxqp.Tag", "methodName" => "include")));
	}
	public function fixPath($a) {
		if(hxqp_XTagCommon::$nocache_) {
			$a .= "?" . _hx_string_rec(hxqp_XXLib::microtime(null), "");
		}
		return $a;
	}
	public function _print() {
		return $this->parent_->hprint();
	}
	public function hprint() {
		echo("" . _hx_string_or_null($this->str(null)));
		return $this;
	}
	public function str($h = null) {
		if($h === null) {
			$h = "";
		}
		$ret = $h;
		if($this->tag_ !== null && _hx_index_of($this->tag_, "_", null) < 0) {
			$attr = "";
			{
				$_g = 0; $_g1 = XReflect::fields($this->attr_);
				while($_g < $_g1->length) {
					$a = $_g1[$_g];
					++$_g;
					if(hxqp_XTag_7($this, $_g, $_g1, $a, $attr, $h, $ret) !== "string") {
						haxe_XLog::trace(hxqp_XTag_8($this, $_g, $_g1, $a, $attr, $h, $ret), _hx_anonymous(array("fileName" => "Tag.hx", "lineNumber" => 201, "className" => "hxqp.Tag", "methodName" => "str")));
						continue;
					}
					$attr .= _hx_string_or_null(hxqp_XXLib::sprintf(" %s='%s'", (($a === "c") ? "class" : $a), hxqp_XTag_9($this, $_g, $_g1, $a, $attr, $h, $ret), null, null, null, null, null, null, null));
					unset($a);
				}
			}
			$ret .= _hx_string_or_null(hxqp_XXLib::sprintf("<%s%s>", $this->tag_, $attr, null, null, null, null, null, null, null));
		}
		if($this->text_ !== null) {
			$ret .= _hx_string_or_null($this->text_);
		}
		{
			$_g = 0; $_g1 = $this->children_;
			while($_g < $_g1->length) {
				$c = $_g1[$_g];
				++$_g;
				$ret .= _hx_string_or_null($c->str(_hx_string_or_null($h) . " "));
				unset($c);
			}
		}
		if($this->tag_ !== null && _hx_index_of($this->tag_, "_", null) < 0) {
			$ret .= _hx_string_or_null(hxqp_XXLib::sprintf("</%s>", $this->tag_, null, null, null, null, null, null, null, null));
		}
		$ret .= "\x0A";
		return $ret;
	}
	public function dump($h = null) {
		if($h === null) {
			$h = "";
		}
		$ret = $h;
		$ret .= _hx_string_or_null(hxqp_XTag_10($this, $h, $ret));
		$ret .= _hx_string_or_null(hxqp_XTag_11($this, $h, $ret));
		$ret .= _hx_string_or_null(hxqp_XTag_12($this, $h, $ret));
		$ret .= "\x0A";
		{
			$_g = 0; $_g1 = $this->children_;
			while($_g < $_g1->length) {
				$c = $_g1[$_g];
				++$_g;
				$ret .= _hx_string_or_null($c->dump(_hx_string_or_null($h) . " "));
				unset($c);
			}
		}
		return $ret;
	}
	public function _html($html) {
		return $this->parent_->html($html);
	}
	public function html($html) {
		return $this->tag("_html", null, $html);
	}
	public function indexOf($children) {
		$i = 0;
		{
			$_g = 0; $_g1 = $this->children_;
			while($_g < $_g1->length) {
				$c = $_g1[$_g];
				++$_g;
				if($c === $children) {
					return $i;
				}
				$i++;
				unset($c);
			}
		}
		return -1;
	}
	public function _find($tag) {
		return $this->parent_->find($tag);
	}
	public function find($tag) {
		{
			$_g = 0; $_g1 = $this->children_;
			while($_g < $_g1->length) {
				$c = $_g1[$_g];
				++$_g;
				if($c->tag_ === $tag) {
					return $c;
				}
				unset($c);
			}
		}
		return null;
	}
	public function _utag($tag, $attr = null, $text = null) {
		return $this->parent_->utag($tag, $attr, $text);
	}
	public function utag($tag, $attr = null, $text = null) {
		$t = new hxqp_XTag($this, $tag, $attr, $text, null);
		if(XLambda::indexOf($this->children_, $t) === -1) {
			$this->children_->push($t);
		}
		return $this->children_[$this->children_->length - 1];
	}
	public function _tag($tag, $attr = null, $text = null) {
		return $this->parent_->tag($tag, $attr, $text);
	}
	public function tag($tag, $attr = null, $text = null) {
		$this->children_->push(new hxqp_XTag($this, $tag, $attr, $text, null));
		return $this->children_[$this->children_->length - 1];
	}
	public function parents() {
		$tt = new _hx_array(array());
		$t = $this;
		while($t->parent_ !== null) {
			$tt->push($t = $t->parent_);
		}
		return $tt;
	}
	public function _top() {
		return $this->parent_->top();
	}
	public function top() {
		$t = $this;
		while($t->parent_ !== null) {
			$t = $t->parent_;
		}
		return $t;
	}
	public function id() {
		if(_hx_field($this->attr_, "id") === null) {
			$this->attr_->id = hxqp_XTag_13($this);
		}
		return $this->attr_->id;
	}
	public $from_;
	public $children_;
	public $text_;
	public $attr_;
	public $tag_;
	public $parent_;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static $root_ = null;
	static function root() {
		if(hxqp_XTag::$root_ === null) {
			hxqp_XTag::$root_ = new hxqp_XTag(null, "div", _hx_anonymous(array("url" => hxqp_XProject::URL(null), "id" => hxqp_XProject::packageName())), null, null);
			hxqp_XTag::$root_->talert("Dialog:" . _hx_string_or_null(hxqp_XProject::URL(null)));
		}
		return hxqp_XTag::$root_;
	}
	static function addClass($a, $x) {
		$c = "class";
		$y = XReflect::field($a, $c);
		$a->{$c} = _hx_string_or_null((hxqp_XTag_14($a, $c, $x, $y))) . _hx_string_or_null($x);
		return $a;
	}
	static function includeCSS($tag, $path) { return call_user_func_array(self::$includeCSS, array($tag, $path)); }
	public static $includeCSS = null;
	static function includeJS($tag, $path) { return call_user_func_array(self::$includeJS, array($tag, $path)); }
	public static $includeJS = null;
	function __toString() { return 'hxqp.Tag'; }
}
hxqp_XTag::$includeCSS = array(new _hx_lambda(array(), "hxqp_XTag_15"), 'execute');
hxqp_XTag::$includeJS = array(new _hx_lambda(array(), "hxqp_XTag_16"), 'execute');
function hxqp_XTag_0(&$__hx__this, &$model) {
	{
		$t = $__hx__this->top()->tag("div", _hx_anonymous(array("style" => "display:none")), null);
		$t->id();
		return $t;
	}
}
function hxqp_XTag_1(&$__hx__this, &$level, &$model, &$t, &$url, &$v) {
	{
		$t1 = $__hx__this->tag("span", _hx_anonymous(array("param" => hxqp_XXLib::serialize($v, null), "level_" => $level)), null);
		$t1->id();
		return $t1;
	}
}
function hxqp_XTag_2(&$__hx__this, &$level, &$model, &$t, &$url, &$v) {
	{
		$t1 = $__hx__this->tag("div", _hx_anonymous(array("c" => "container", "param" => hxqp_XXLib::serialize($v, null), "level_" => $level)), null);
		$t1->id();
		return $t1;
	}
}
function hxqp_XTag_3(&$__hx__this, &$level, &$model, &$t, &$url, &$v) {
	{
		$s = $t->attr_->id;
		return "'" . _hx_string_or_null(str_replace("'", "\\'", $s)) . "'";
	}
}
function hxqp_XTag_4(&$__hx__this, &$a, &$h, &$hh, &$href, &$hrender, &$id, &$ul) {
	if($href === null) {
		return "#" . _hx_string_or_null($id);
	} else {
		return $href;
	}
}
function hxqp_XTag_5(&$__hx__this, &$attr, &$text) {
	{
		$t = $__hx__this->parent_->tag("span", $attr, $text);
		$t->id();
		return $t;
	}
}
function hxqp_XTag_6(&$__hx__this, &$attr, &$text) {
	{
		$t = $__hx__this->parent_->tag("div", $attr, $text);
		$t->id();
		return $t;
	}
}
function hxqp_XTag_7(&$__hx__this, &$_g, &$_g1, &$a, &$attr, &$h, &$ret) {
	{
		$t = gettype($a);
		if($t === "object") {
			$t = get_class($a);
		}
		return $t;
	}
}
function hxqp_XTag_8(&$__hx__this, &$_g, &$_g1, &$a, &$attr, &$h, &$ret) {
	{
		$t = gettype($a);
		if($t === "object") {
			$t = get_class($a);
		}
		return $t;
	}
}
function hxqp_XTag_9(&$__hx__this, &$_g, &$_g1, &$a, &$attr, &$h, &$ret) {
	{
		$s = XReflect::field($__hx__this->attr_, $a);
		return str_replace("'", "\\'", $s);
	}
}
function hxqp_XTag_10(&$__hx__this, &$h, &$ret) {
	if($__hx__this->tag_ === null) {
		return "NULL";
	} else {
		if($__hx__this->tag_ === "") {
			return "Null";
		} else {
			return $__hx__this->tag_;
		}
	}
}
function hxqp_XTag_11(&$__hx__this, &$h, &$ret) {
	if(_hx_field($__hx__this->attr_, "id") === null) {
		return "";
	} else {
		return "[" . XStd::string($__hx__this->attr_->id) . "]";
	}
}
function hxqp_XTag_12(&$__hx__this, &$h, &$ret) {
	if($__hx__this->from_ === null) {
		return "";
	} else {
		return " :" . _hx_string_or_null($__hx__this->from_);
	}
}
function hxqp_XTag_13(&$__hx__this) {
	if($__hx__this->parent_ !== null) {
		return _hx_string_or_null($__hx__this->parent_->id()) . "_" . _hx_string_rec($__hx__this->parent_->indexOf($__hx__this), "");
	} else {
		return parent::nextid();
	}
}
function hxqp_XTag_14(&$a, &$c, &$x, &$y) {
	if($y === null) {
		return "";
	} else {
		return _hx_string_or_null($y) . " ";
	}
}
function hxqp_XTag_15($tag, $path) {
	{
		$e = new XEReg("(.*/)*(.*)\\.css", null);
		if(!$e->match($path)) {
			haxe_XLog::trace("includeCSS: " . _hx_string_or_null($path), _hx_anonymous(array("fileName" => "Tag.hx", "lineNumber" => 253, "className" => "hxqp.Tag", "methodName" => "includeCSS")));
			return;
		}
		$h = hxqp_XTag_17($e, $path, $tag);
		$tag->utag("link", _hx_anonymous(array("href" => $path, "rel" => "stylesheet", "type" => "text/css", "media" => "all")), null);
	}
}
function hxqp_XTag_16($tag, $path) {
	{
		$e = new XEReg("(.*/)*(.*)\\.js", null);
		if(!$e->match($path)) {
			haxe_XLog::trace("includeJS: " . _hx_string_or_null($path), _hx_anonymous(array("fileName" => "Tag.hx", "lineNumber" => 260, "className" => "hxqp.Tag", "methodName" => "includeJS")));
			return;
		}
		$h = hxqp_XTag_18($e, $path, $tag);
		$tag->utag("script", _hx_anonymous(array("src" => $path)), null);
	}
}
function hxqp_XTag_17(&$e, &$path, &$tag) {
	{
		$s = $e->matched(2);
		return str_replace(".", "-", $s);
	}
}
function hxqp_XTag_18(&$e, &$path, &$tag) {
	{
		$s = $e->matched(2);
		return str_replace(".", "-", $s);
	}
}
