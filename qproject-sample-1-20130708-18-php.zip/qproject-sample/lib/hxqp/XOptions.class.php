<?php

class hxqp_XOptions implements hxqp_XHavingName, XIMap, hxqp_XITag{
	public function __construct() {
		if(!php_XBoot::$skip_constructor) {
		$this->sections_ = new _hx_array(array());
	}}
	public function render($page) {
		$page->hinclude("/ext/jquery.js");
		$page->tag("div", _hx_anonymous(array("id" => _hx_string_or_null($this->name1()) . "-tabs")), null)->tabs($this->sections_->iterator(), null);
		$page->tag("br", null, null)->input("button", _hx_anonymous(array("value" => "Home", "onclick" => "location.href=hxqp.Project.URL()+\"/index.php\"")));
	}
	public function section($title, $render = null, $href = null) {
		$ss = $this->sections_->filter(array(new _hx_lambda(array(&$href, &$render, &$title), "hxqp_XOptions_0"), 'execute'));
		if($ss->length > 0) {
			return $ss[0];
		}
		$n = $this->sections_->push(new hxqp_XSection($this, $title, $render, $href));
		return $this->sections_[$n - 1];
	}
	public function name1() {
		return "qproject_sample";
	}
	public function toString() {
		return "[Options]";
	}
	public function iterator() {
		return null;
	}
	public function keys() {
		return null;
	}
	public function remove($k) {
		$ret = false;
		{
			$_g = 0; $_g1 = $this->sections_;
			while($_g < $_g1->length) {
				$s = $_g1[$_g];
				++$_g;
				$ret = $s->options_->remove($k) || $ret;
				unset($s);
			}
		}
		return $ret;
	}
	public function exists($k) {
		{
			$_g = 0; $_g1 = $this->sections_;
			while($_g < $_g1->length) {
				$s = $_g1[$_g];
				++$_g;
				if($s->options_->exists($k)) {
					return true;
				}
				unset($s);
			}
		}
		return false;
	}
	public function set($k, $v) {
		$_g = 0; $_g1 = $this->sections_;
		while($_g < $_g1->length) {
			$s = $_g1[$_g];
			++$_g;
			if($s->options_->exists($k)) {
				$s->options_->get($k)->setValue($v);
			}
			unset($s);
		}
	}
	public function get($k) {
		{
			$_g = 0; $_g1 = $this->sections_;
			while($_g < $_g1->length) {
				$s = $_g1[$_g];
				++$_g;
				if($s->options_->exists($k)) {
					return $s->options_->get($k)->value();
				}
				unset($s);
			}
		}
		return null;
	}
	public function getOption($k) {
		{
			$_g = 0; $_g1 = $this->sections_;
			while($_g < $_g1->length) {
				$s = $_g1[$_g];
				++$_g;
				if($s->options_->exists($k)) {
					return $s->options_->get($k);
				}
				unset($s);
			}
		}
		return null;
	}
	public $sections_;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	function __toString() { return $this->toString(); }
}
function hxqp_XOptions_0(&$href, &$render, &$title, $s) {
	{
		return $s->title_ === $title;
	}
}
