<?php

class hxqp__Data_XSql_Impl_ {
	public function __construct(){}
	static function pdo($db) {
		return new hxqp_data_XPDO2($db, null, null, null);
	}
	static function sdb($db) {
		return new hxqp_data_XSysDB($db, null, null, null);
	}
	function __toString() { return 'hxqp._Data.Sql_Impl_'; }
}
