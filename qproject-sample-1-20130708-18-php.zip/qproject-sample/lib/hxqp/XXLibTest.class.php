<?php

class hxqp_XXLibTest extends haxe_unit_XTestCase {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	public function testStack() {
		hxqp_XXLib::callFrom(null);
		$this->assertEquals(1, 1, _hx_anonymous(array("fileName" => "XLib.hx", "lineNumber" => 309, "className" => "hxqp.XLibTest", "methodName" => "testStack")));
	}
	function __toString() { return 'hxqp.XLibTest'; }
}
