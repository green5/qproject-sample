<?php

class hxqp_XTUser extends sys_db_XObject implements hxqp_XTObject{
	public function __construct($name_, $group_ = null) {
		if(!php_XBoot::$skip_constructor) {
		parent::__construct();
		$this->name = $name_;
		$this->set_group(hxqp_XTGroup::group((($group_ === null) ? $name_ : $group_)));
	}}
	public function set_group($_v) {
		return hxqp_XTGroup::$manager->h__set($this, "group", "gid", $_v);
	}
	public function get_group() {
		return hxqp_XTGroup::$manager->h__get($this, "group", "gid", false);
	}
	public $country = "ru";
	public $about;
	public $address;
	public $email;
	public $phone;
	public $company;
	public $age;
	public $name;
	public $uid;
	public function id() {
		return $this->uid;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function user($name_, $group_ = null) {
		$t = hxqp_XTUser::$manager->unsafeObjects("SELECT * FROM TUser WHERE name = " . _hx_string_or_null(sys_db_XManager::quoteAny($name_)), null)->first();
		if($t === null) {
			_hx_deref(($t = new hxqp_XTUser($name_, $group_)))->insert();
		}
		return $t;
	}
	static $manager;
	static $__properties__ = array("set_group" => "set_group","get_group" => "get_group");
	function __toString() { return 'hxqp.TUser'; }
}
hxqp_XTUser::$__meta__ = _hx_anonymous(array("obj" => _hx_anonymous(array("rtti" => new _hx_array(array("oy4:namey5:TUsery7:indexesahy9:relationsaoy4:lockfy4:propy5:groupy4:typey11:hxqp.TGroupy7:cascadefy6:isNullfy3:keyy3:gidghy7:hfieldsbR0oR0R0R10fy1:tjy17:sys.db.RecordType:9:1i767gy5:phoneoR0R16R10tR14jR15:15:0gy3:uidoR0R17R10fR14jR15:0:0gR12oR0R12R10fR14jR15:1:0gy7:addressoR0R18R10tR14r8gy5:aboutoR0R19R10tR14r8gy7:countryoR0R20R10tR14r8gy5:emailoR0R21R10tR14r8gy7:companyoR0R22R10tR14r8gy3:ageoR0R23R10tR14r8ghR11aR17hy6:fieldsar9r5r18r17r7r16r13r14r15r11hg"))))));
hxqp_XTUser::$manager = new sys_db_XManager(_hx_qtype("hxqp.TUser"));
