<?php

class hxqp_XLocalDBTest extends haxe_unit_XTestCase {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		parent::__construct();
	}}
	public function test2() {
		new hxqp_XLocalDB();
		haxe_XLog::trace(hxqp_XTProject::$manager, _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 235, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
		$t = hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE 1 = 1", null);
		$this->assertTrue($t->length >= 3, _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 237, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
		if(null == $t) throw new HException('null iterable');
		$__hx__it = $t->iterator();
		while($__hx__it->hasNext()) {
			$i = $__hx__it->next();
			haxe_XLog::trace(XReflect::fields($i), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 240, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
			haxe_XLog::trace($i->get_group(), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 241, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
			$i->state = "test1";
			$i->update();
		}
		$t1 = hxqp_XTProject::$manager->dynamicSearch(_hx_anonymous(array("1" => 1)), null);
		$this->assertTrue($t1->length >= 3, _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 246, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
		$m = hxqp_XLocalDB::model("TProject");
		if(null == $t1) throw new HException('null iterable');
		$__hx__it = $t1->iterator();
		while($__hx__it->hasNext()) {
			$i = $__hx__it->next();
			haxe_XLog::trace(XReflect::fields($i), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 250, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
			haxe_XLog::trace($i->get_group(), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 251, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
			$i->state = "test2";
			$i->update();
			haxe_XLog::trace($m->ui($i), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 254, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
		}
		$r = $t1->first();
		hxqp_XXLib::trace_(hxqp_XTProject::ui(null), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 257, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
		hxqp_XXLib::trace_(hxqp_XTProject::ui($r), _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 258, "className" => "hxqp.LocalDBTest", "methodName" => "test2")));
	}
	public function test1() {
		$z = hxqp_XTProject::project("Test", null);
		$u = hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE name = 'Test'", null)->first();
		if(null == hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE name = 'Test'", null)) throw new HException('null iterable');
		$__hx__it = hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE name = 'Test'", null)->iterator();
		while($__hx__it->hasNext()) {
			$i = $__hx__it->next();
			$this->assertEquals($u, $i, _hx_anonymous(array("fileName" => "LocalDB.hx", "lineNumber" => 229, "className" => "hxqp.LocalDBTest", "methodName" => "test1")));
		}
	}
	function __toString() { return 'hxqp.LocalDBTest'; }
}
