<?php

class hxqp_XTLink extends sys_db_XObject implements hxqp_XTObject{
	public function __construct($p, $u) {
		if(!php_XBoot::$skip_constructor) {
		parent::__construct();
		$this->pid = $p->id();
		$this->uid = $u->id();
		date_default_timezone_set("GMT+0");
		$this->ltime = XDate::now()->getTime() / 1000.;
	}}
	public function set_user($_v) {
		return hxqp_XTUser::$manager->h__set($this, "user", "uid", $_v);
	}
	public function get_user() {
		return hxqp_XTUser::$manager->h__get($this, "user", "uid", false);
	}
	public function set_project($_v) {
		return hxqp_XTProject::$manager->h__set($this, "project", "pid", $_v);
	}
	public function get_project() {
		return hxqp_XTProject::$manager->h__get($this, "project", "pid", false);
	}
	public $ltime;
	public $uid;
	public $pid;
	public $lid;
	public function id() {
		return $this->lid;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function ui($t = null) {
		if($t === null) {
			return _hx_anonymous(array("lid" => "Id", "user" => "User", "project" => "Проект", "state" => "State", "time" => "Created"));
		}
		return _hx_anonymous(array("lid" => $t->lid, "user" => $t->get_user()->name, "project" => $t->get_project()->name, "state" => "unknown", "time" => "" . XStd::string(XDate::fromTime($t->ltime * 1000))));
	}
	static function link($project_, $user_) {
		$p = hxqp_XTProject::$manager->unsafeObjects("SELECT * FROM TProject WHERE name = " . _hx_string_or_null(sys_db_XManager::quoteAny($project_)), null)->first();
		$u = hxqp_XTUser::$manager->unsafeObjects("SELECT * FROM TUser WHERE name = " . _hx_string_or_null(sys_db_XManager::quoteAny($user_)), null)->first();
		if($p === null) {
			throw new HException("link: bad project " . _hx_string_or_null($project_));
		}
		if($u === null) {
			throw new HException("link: bad user " . _hx_string_or_null($user_));
		}
		$l = hxqp_XTLink::$manager->unsafeObjects("SELECT * FROM TLink WHERE pid = " . _hx_string_or_null(sys_db_XManager::quoteAny($p->id())) . _hx_string_or_null((" AND uid = " . _hx_string_or_null(sys_db_XManager::quoteAny($u->id())))), null)->first();
		if($l === null) {
			_hx_deref(($l = new hxqp_XTLink($p, $u)))->insert();
		}
		return $l;
	}
	static $manager;
	static $__properties__ = array("set_project" => "set_project","get_project" => "get_project","set_user" => "set_user","get_user" => "get_user");
	function __toString() { return 'hxqp.TLink'; }
}
hxqp_XTLink::$__meta__ = _hx_anonymous(array("obj" => _hx_anonymous(array("rtti" => new _hx_array(array("oy4:namey5:TLinky7:indexesahy9:relationsaoy4:lockfy4:propy7:projecty4:typey13:hxqp.TProjecty7:cascadefy6:isNullfy3:keyy3:pidgoR4fR5y4:userR7y10:hxqp.TUserR9fR10fR11y3:uidghy7:hfieldsbR12oR0R12R10fy1:tjy17:sys.db.RecordType:1:0gy5:ltimeoR0R19R10fR17jR18:7:0gy3:lidoR0R20R10fR17jR18:0:0gR15oR0R15R10fR17r7ghR11aR20hy6:fieldsar10r6r12r8hg"))))));
hxqp_XTLink::$manager = new sys_db_XManager(_hx_qtype("hxqp.TLink"));
