<?php

interface hxqp_XData {
	function connection();
	function query($req, $arg = null, $style = null, $nrow = null);
}
