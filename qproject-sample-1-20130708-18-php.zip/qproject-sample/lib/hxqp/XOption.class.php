<?php

class hxqp_XOption {
	public function __construct($parent, $name, $title, $attr, $render = null) {
		if(!php_XBoot::$skip_constructor) {
		$this->parent_ = $parent;
		$this->name_ = $name;
		$this->attr_ = $attr;
		$this->title_ = $title;
		$this->render_ = $render;
	}}
	public function validate($value) {
		return null;
	}
	public function setValue($v) {
		$this->attr_->value = $v;
	}
	public function value() {
		return $this->attr_->value;
	}
	public function hprint() {
		$temp = hxqp_XTag::root();
		$this->render($temp);
		$temp->hprint();
	}
	public function render($parent) {
		$this->attr_->size = 40;
		$this->attr_->id = $this->name_;
		$this->attr_->name = hxqp_XXLib::sprintf("%s[%s]", _hx_string_or_null($this->parent_->name1()) . "_options", $this->name_, null, null, null, null, null, null, null);
		$this->attr_->value = $this->value();
		$parent->input("text", $this->attr_);
		if($this->render_ !== null) {
			$this->render_($parent);
		}
	}
	public $render_;
	public $attr_;
	public $parent_;
	public $title_;
	public $name_;
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function _new($parent, $name, $title, $attr, $render = null) { return call_user_func_array(self::$_new, array($parent, $name, $title, $attr, $render)); }
	public static $_new = null;
	function __toString() { return 'hxqp.Option'; }
}
hxqp_XOption::$_new = array(new _hx_lambda(array(), "hxqp_XOption_0"), 'execute');
function hxqp_XOption_0($parent, $name, $title, $attr, $render) {
	{
		return new hxqp_XOption($parent, $name, $title, $attr, $render);
	}
}
