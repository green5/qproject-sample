<?php

class hxqp_XXLib {
	public function __construct(){}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function _typeof($x) {
		$t = gettype($x);
		if($t === "object") {
			$t = get_class($x);
		}
		return $t;
	}
	static function aa($a = null) {
		if($a === null) {
			return array();
		}
		return $a->a;
	}
	static function trace_() { $args = func_get_args(); return call_user_func_array(self::$trace_, $args); }
	static $trace_;
	static function syslog($t) {
		
		  openlog('X',1,128); 
			foreach(explode("
",$t) as $m) syslog(7, $m);
			closelog();
		;
	}
	static function syserr($t) {
		
		  global $ferr; 
			if($ferr==null) $ferr = fopen('php://stderr', 'w');
			fprintf($ferr, '%s
', $t); 
		;
	}
	static function xtrace($x, $i = null) {
		$h = hxqp_XXLib_0($i, $x);
		$h .= _hx_string_or_null(hxqp_XXLib_1($h, $i, $x)) . "=>" . XStd::string(XType::getClass($x)) . ":";
		hxqp_XXLib::syserr(_hx_string_or_null($h) . XStd::string($x));
	}
	static $vcallException_ = true;
	static function xcheck($func) {
		if(is_callable($func)) {
			return true;
		}
		if(hxqp_XXLib::$vcallException_) {
			throw new HException("uncallable: " . XStd::string($func));
		}
		return false;
	}
	static function x0($func) {
		return call_user_func_array($__call__, array($func));
	}
	static function x1($func, $a1) {
		return call_user_func_array($__call__, array($func, $a1));
	}
	static function x2($func, $a1, $a2) {
		return call_user_func_array($__call__, array($func, $a1, $a2));
	}
	static function x3($func, $a1, $a2, $a3) {
		return call_user_func_array($__call__, array($func, $a1, $a2, $a3));
	}
	static function x4($func, $a1, $a2, $a3, $a4) {
		return call_user_func_array($__call__, array($func, $a1, $a2, $a3, $a4));
	}
	static function x5($func, $a1, $a2, $a3, $a4, $a5) {
		return call_user_func_array($__call__, array($func, $a1, $a2, $a3, $a4, $a5));
	}
	static function vcall($func, $arg) {
		if(hxqp_XXLib::xcheck($func)) {
			return call_user_func_array($func, $arg->a);
		}
		return false;
	}
	static function ob_vcall($func, $arg) {
		ob_start();
		ob_implicit_flush(false);
		hxqp_XXLib::vcall($func, $arg);
		return ob_get_clean();
	}
	static function printf($fmt, $Dynamic = null, $Dynamic1 = null, $Dynamic2 = null, $Dynamic3 = null, $Dynamic4 = null, $Dynamic5 = null, $Dynamic6 = null, $Dynamic7 = null, $Dynamic8 = null) {
		return call_user_func_array('printf',func_get_args());
	}
	static function sprintf($fmt, $Dynamic = null, $Dynamic1 = null, $Dynamic2 = null, $Dynamic3 = null, $Dynamic4 = null, $Dynamic5 = null, $Dynamic6 = null, $Dynamic7 = null, $Dynamic8 = null) {
		return call_user_func_array('sprintf',func_get_args());
	}
	static function isget($z, $o, $prop = null) {
		
			if(is_string($o) && isset($GLOBALS[$o]))
			{
				$o = $GLOBALS[$o];
			}
			$arg = func_get_args();
			for($i=2;$i<count($arg) && $arg[$i];$i++)	
			{
				$n = $arg[$i];
		    if(is_object($o) && isset($o->$n)) $o=$o->$n;
		  	else if(is_array($o) && isset($o[$n])) $o=$o[$n];
				else { $o=$z; break; }
			}
		;
		return $o;
	}
	static function hprint($t) {
		echo("" . _hx_string_or_null($t));
	}
	static function println($t) {
		echo("" . _hx_string_or_null((_hx_string_or_null($t) . "\x0A")));
	}
	static function hexit($ret = null) {
		if($ret === null) {
			$ret = 0;
		}
		exit($ret);
	}
	static function count($a) {
		return count($a);
	}
	static function hx_object($a, $recursive = null) {
		if($recursive === null) {
			$recursive = false;
		}
		
			if(is_array($a)) $o = new _hx_array($a);
			{
				$o = _hx_anonymous();
				foreach($a as $k => $x)
					$o->$k = is_array($x) ? hxqp_XLib::hx_object($x) : $x;
				return $o;
			}
			return (object)$a;
		;
		return $a;
	}
	static function microtime($n = null) {
		if($n === null) {
			$n = 0;
		}
		return round(microtime(true), $n);
	}
	static function extend($t, $o) {
		if($t === null) {
			$t = _hx_anonymous(array());
		}
		if($o === null) {
			$o = _hx_anonymous(array());
		}
		{
			$_g = 0; $_g1 = XReflect::fields($o);
			while($_g < $_g1->length) {
				$i = $_g1[$_g];
				++$_g;
				$t->{$i} = XReflect::field($o, $i);
				unset($i);
			}
		}
		return $t;
	}
	static function q($s) {
		return "'" . _hx_string_or_null(str_replace("'", "\\'", $s)) . "'";
	}
	static function qq($s) {
		return "\"" . _hx_string_or_null(str_replace("\"", "\\\"", $s)) . "\"";
	}
	static function serialize($o, $q = null) {
		if($q === null) {
			$q = 0;
		}
		$t = new haxe_XSerializer();
		$t->serialize($o);
		$s = $t->toString();
		if($q === 1) {
			$s = "'" . _hx_string_or_null(str_replace("'", "\\'", $s)) . "'";
		}
		if($q === 2) {
			$s = "\"" . _hx_string_or_null(str_replace("\"", "\\\"", $s)) . "\"";
		}
		return $s;
	}
	static function unserialize($s) {
		return _hx_deref(new haxe_XUnserializer($s))->unserialize();
	}
	static function pserialize($o) {
		$s = json_encode($o);
		return $s;
	}
	static function punserialize($s) {
		return json_decode($s);
	}
	static function stackToString($b, $s) {
		$_g = 0; $_g1 = new _hx_array(array("file", "line", "class", "function", "object", "type"));
		while($_g < $_g1->length) {
			$i = $_g1[$_g];
			++$_g;
			if(XReflect::field($s, $i)) {
				$b->add(_hx_string_or_null($i) . "=" . XStd::string(XReflect::field($s, $i)) . ";");
			}
			unset($i);
		}
	}
	static function phpStack() {
		$tt = new _hx_array(array());
		
		$ss = debug_backtrace();
		array_shift($ss);
		foreach($ss as $s) 
		{
			if(isset($s['file'])) $s['file'] = basename($s['file']);
			$t = array();
			foreach(array('file','line','function','class','_object','type','_args') as $k)
			{
				if(isset($s[$k])) $t[$k] = $s[$k];
			}
			$tt->push(_hx_anonymous($t));
		}
		;
		return $tt;
	}
	static function callFrom($n = null) {
		if($n === null) {
			$n = 2;
		}
		$b = new XStringBuf();
		$ss = hxqp_XXLib::phpStack();
		if($n < 0) {
			$n = $ss->length + $n;
		}
		if($n >= 0 && $ss->length > 0) {
			hxqp_XXLib::stackToString($b, $ss[_hx_mod($n, $ss->length)]);
		}
		return $b->b;
	}
	static function ucfirst($m) {
		return ucfirst($m);
	}
	function __toString() { return 'hxqp.XLib'; }
}
hxqp_XXLib::$__meta__ = _hx_anonymous(array("statics" => _hx_anonymous(array("_typeof" => _hx_anonymous(array("php" => null)), "println" => _hx_anonymous(array("any" => null)), "extend" => _hx_anonymous(array("any" => null)), "q" => _hx_anonymous(array("any" => null)), "qq" => _hx_anonymous(array("any" => null)), "serialize" => _hx_anonymous(array("any" => null)), "unserialize" => _hx_anonymous(array("any" => null)), "ucfirst" => _hx_anonymous(array("php" => null))))));
hxqp_XXLib::$trace_ = haxe_XLog::$trace;
function hxqp_XXLib_0(&$i, &$x) {
	if($i === null) {
		return "";
	} else {
		return _hx_string_or_null($i->fileName) . "." . _hx_string_rec($i->lineNumber, "") . ":";
	}
}
function hxqp_XXLib_1(&$h, &$i, &$x) {
	{
		$t = gettype($x);
		if($t === "object") {
			$t = get_class($x);
		}
		return $t;
	}
}
