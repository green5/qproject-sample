<?php

class hxqp_XMain {
	public function __construct() { if(!php_XBoot::$skip_constructor) {
		$h = new XHList();
	}}
	public function tmain($isCli, $req) {
		$c = new hxqp_cms_XWP();
		hxqp_XMain::makeOptionPage($c->options());
		if(_hx_field($req, "__x") !== null) {
			$ctx = new haxe_remoting_XContext();
			$ctx->addObject("Remote", new hxqp_XRemote(), null);
			if(haxe_remoting_XHttpConnection::handleRequest($ctx)) {
				return;
			}
		}
		if(php_XWeb::getMethod() === "GET" && _hx_field($req, "loadData") !== null) {
			$ret = new _hx_array(array());
			if(_hx_equal($req->loadData, "bbGrid")) {
				$ret = _hx_deref(new hxqp_XRemote())->bbGrid("GET", $req->url, "-1", _hx_anonymous(array("rowid" => $req->rowid)));
				$ret = $ret->a;
			}
			if(_hx_equal($req->loadData, "jqGrid")) {
				$ret = _hx_deref(new hxqp_XRemote())->jqGrid($req);
			}
			{
				$t = json_encode($ret);
				echo("" . _hx_string_or_null($t));
			}
		}
		$c->hooks();
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function main() {
		$isCli = php_XLib::isCli();
		if($isCli) {
			$a = new _hx_array(array("", "test"));
			$a = new _hx_array($_SERVER['argv']);
			if($a[1] === "db") {
				_hx_deref(new hxqp_XLocalDB())->drop()->create()->testData();
			}
			if($a[1] === "test") {
				hxqp_XTestMain::main();
			}
			return;
		}
		haxe_XLog::$trace = (isset(hxqp_XXLib::$xtrace) ? hxqp_XXLib::$xtrace: array("hxqp_XXLib", "xtrace"));
		try {
			$req = _hx_anonymous(array());
			if(!$isCli) {
				$req->url = $_SERVER['REQUEST_URI'];
				if(null == php_XWeb::getParams()) throw new HException('null iterable');
				$__hx__it = php_XWeb::getParams()->keys();
				while($__hx__it->hasNext()) {
					$i = $__hx__it->next();
					$req->$i = php_XWeb::getParams()->get($i);
				}
			}
			_hx_deref(new hxqp_XMain())->tmain($isCli, $req);
		}catch(Exception $__hx__e) {
			$_ex_ = ($__hx__e instanceof HException) ? $__hx__e->e : $__hx__e;
			$x = $_ex_;
			{
				haxe_XLog::trace("Main:" . XStd::string($x), _hx_anonymous(array("fileName" => "Main.hx", "lineNumber" => 61, "className" => "hxqp.Main", "methodName" => "main")));
			}
		}
	}
	static function makeOptionPage($o) {
		$o->section("Projects", array(new _hx_lambda(array(&$o), "hxqp_XMain_0"), 'execute'), null);
		$o->section("Users", array(new _hx_lambda(array(&$o), "hxqp_XMain_1"), 'execute'), null);
		$o->section("Groups", array(new _hx_lambda(array(&$o), "hxqp_XMain_2"), 'execute'), null);
		$o->section("Testing", array(new _hx_lambda(array(&$o), "hxqp_XMain_3"), 'execute'), null);
	}
	function __toString() { return 'hxqp.Main'; }
}
hxqp_XMain::$__meta__ = _hx_anonymous(array("statics" => _hx_anonymous(array("main" => _hx_anonymous(array("any" => null)))), "fields" => _hx_anonymous(array("tmain" => _hx_anonymous(array("php" => null)), "_" => _hx_anonymous(array("any" => null))))));
function hxqp_XMain_0(&$o, $parent) {
	{
		$parent->bbGrid("?T=TProject", null)->bbGrid("?T=TLink#pid=:1", null)->bbGrid("?T=TProject#pid=:1", null);
	}
}
function hxqp_XMain_1(&$o, $parent) {
	{
		$parent->bbGrid("?T=TUser", null)->bbGrid("?T=TLink#uid=:1", null);
	}
}
function hxqp_XMain_2(&$o, $parent) {
	{
		$parent->bbGrid("?T=TGroup", null)->bbGrid("?T=TUser#gid=:1", null)->bbGrid("?T=TLink#uid=:1", null);
	}
}
function hxqp_XMain_3(&$o, $parent) {
	{
		$parent->input("button", _hx_anonymous(array("onclick" => "hxqp.Remote.tryadd()", "value" => "1+2")));
	}
}
