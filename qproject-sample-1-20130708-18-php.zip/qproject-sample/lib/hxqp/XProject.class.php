<?php

class hxqp_XProject {
	public function __construct(){}
	static $url_ = null;
	static $package_ = "hxqp";
	static function packageName() {
		return hxqp_XProject::$package_;
	}
	static function setURL($url) {
		hxqp_XProject::$url_ = $url;
	}
	static function URL($name = null) {
		if($name === null) {
			$name = "";
		}
		if(hxqp_XProject::$url_ === null) {
			if(hxqp_XXLib::isget(false, "_SERVER", "SERVER_NAME")) {
				hxqp_XProject::$url_ = "http://" . _hx_string_or_null($_SERVER["SERVER_NAME"]) . ":" . _hx_string_or_null($_SERVER["SERVER_PORT"]) . _hx_string_or_null($_SERVER["REQUEST_URI"]);
			}
		}
		if(hxqp_XProject::$url_ === null) {
			hxqp_XProject::$url_ = "";
		}
		if(_hx_char_at($name, 0) === "?") {
			$q = _hx_index_of(hxqp_XProject::$url_, "?", null);
			if($q < 0) {
				return _hx_string_or_null(hxqp_XProject::$url_) . _hx_string_or_null($name);
			}
			return _hx_string_or_null(hxqp_XProject::$url_) . "&" . _hx_string_or_null(_hx_substring($name, 1, null));
		}
		if(_hx_char_at($name, 0) === "/") {
			$q = _hx_index_of(hxqp_XProject::$url_, "?", null);
			if($q < 0) {
				return _hx_string_or_null(hxqp_XProject::$url_) . _hx_string_or_null($name);
			}
			return _hx_string_or_null(_hx_substring(hxqp_XProject::$url_, 0, $q)) . _hx_string_or_null($name) . _hx_string_or_null(_hx_substring(hxqp_XProject::$url_, $q, null));
		}
		$q = _hx_index_of(hxqp_XProject::$url_, "?", null);
		if($q < 0) {
			return _hx_string_or_null(hxqp_XProject::$url_) . _hx_string_or_null((hxqp_XProject_0($name, $q)));
		}
		return _hx_string_or_null(_hx_substring(hxqp_XProject::$url_, 0, $q)) . _hx_string_or_null($name) . _hx_string_or_null(_hx_substring(hxqp_XProject::$url_, $q, null));
	}
	static function root() {
		return hxqp_XTag::root();
	}
	function __toString() { return 'hxqp.Project'; }
}
function hxqp_XProject_0(&$name, &$q) {
	if(_hx_substr(hxqp_XProject::$url_, -1, null) === "/") {
		return $name;
	} else {
		return "/" . _hx_string_or_null($name);
	}
}
