<?php

class hxqp_XTagCommon {
	public function __construct(){}
	public function nextid() {
		return "temp" . _hx_string_rec(++hxqp_XTagCommon::$id_, "");
	}
	static $nocache_ = true;
	static $id_ = 0;
	static $kid_;
	static function testid($id, $info) {
		if(hxqp_XTagCommon::$kid_->get($id) !== null) {
			haxe_XLog::trace(hxqp_XXLib::callFrom(null), _hx_anonymous(array("fileName" => "Tag.hx", "lineNumber" => 46, "className" => "hxqp.TagCommon", "methodName" => "testid")));
			throw new HException(_hx_string_or_null($id) . ":" . _hx_string_or_null($info) . "<=" . _hx_string_or_null(hxqp_XTagCommon::$kid_->get($id)));
		}
		{
			hxqp_XTagCommon::$kid_->set($id, $info);
			$info;
		}
	}
	function __toString() { return 'hxqp.TagCommon'; }
}
hxqp_XTagCommon::$kid_ = new haxe_ds_XStringMap();
