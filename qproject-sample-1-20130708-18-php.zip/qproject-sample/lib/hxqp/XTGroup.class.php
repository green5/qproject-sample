<?php

class hxqp_XTGroup extends sys_db_XObject implements hxqp_XTObject{
	public function __construct($name_) {
		if(!php_XBoot::$skip_constructor) {
		parent::__construct();
		$this->name = $name_;
	}}
	public $name;
	public $gid;
	public function id() {
		return $this->gid;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->__dynamics[$m]) && is_callable($this->__dynamics[$m]))
			return call_user_func_array($this->__dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call <'.$m.'>');
	}
	static function __meta__() { $args = func_get_args(); return call_user_func_array(self::$__meta__, $args); }
	static $__meta__;
	static function group($name_) {
		$t = hxqp_XTGroup::$manager->unsafeObjects("SELECT * FROM TGroup WHERE name = " . _hx_string_or_null(sys_db_XManager::quoteAny($name_)), null)->first();
		if($t === null) {
			_hx_deref(($t = new hxqp_XTGroup($name_)))->insert();
		}
		return $t;
	}
	static $manager;
	function __toString() { return 'hxqp.TGroup'; }
}
hxqp_XTGroup::$__meta__ = _hx_anonymous(array("obj" => _hx_anonymous(array("rtti" => new _hx_array(array("oy4:namey6:TGroupy7:indexesahy9:relationsahy7:hfieldsby3:gidoR0R5y6:isNullfy1:tjy17:sys.db.RecordType:0:0gR0oR0R0R6fR7jR8:9:1i767ghy3:keyaR5hy6:fieldsar4r6hg"))))));
hxqp_XTGroup::$manager = new sys_db_XManager(_hx_qtype("hxqp.TGroup"));
