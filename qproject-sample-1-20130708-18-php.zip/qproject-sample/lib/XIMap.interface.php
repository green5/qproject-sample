<?php

interface XIMap {
	function get($k);
}
