<?php

interface sys_db_XResultSet {
	function getFieldsNames();
	function getFloatResult($n);
	function getIntResult($n);
	function getResult($n);
	function results();
	function next();
	function hasNext();
	//;
	//;
}
