<?php

class sys_db_XMysql {
	public function __construct(){}
	static function connect($params) {
		throw new HException("Not implemented for this platform");
		return null;
	}
	function __toString() { return 'sys.db.Mysql'; }
}
