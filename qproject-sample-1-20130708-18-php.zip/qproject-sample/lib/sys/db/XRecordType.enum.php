<?php

class sys_db_XRecordType extends Enum {
	public static $DBigId;
	public static $DBigInt;
	public static $DBinary;
	public static $DBool;
	public static function DBytes($n) { return new sys_db_XRecordType("DBytes", 19, array($n)); }
	public static $DData;
	public static $DDate;
	public static $DDateTime;
	public static $DEncoded;
	public static function DEnum($name) { return new sys_db_XRecordType("DEnum", 31, array($name)); }
	public static function DFlags($flags, $autoSize) { return new sys_db_XRecordType("DFlags", 23, array($flags, $autoSize)); }
	public static $DFloat;
	public static $DId;
	public static $DInt;
	public static $DInterval;
	public static $DLongBinary;
	public static $DMediumInt;
	public static $DMediumUInt;
	public static $DNekoSerialized;
	public static $DNull;
	public static $DSerialized;
	public static $DSingle;
	public static $DSmallBinary;
	public static $DSmallInt;
	public static $DSmallText;
	public static $DSmallUInt;
	public static function DString($n) { return new sys_db_XRecordType("DString", 9, array($n)); }
	public static $DText;
	public static $DTimeStamp;
	public static $DTinyInt;
	public static $DTinyText;
	public static $DTinyUInt;
	public static $DUId;
	public static $DUInt;
	public static $__constructors = array(4 => 'DBigId', 5 => 'DBigInt', 18 => 'DBinary', 8 => 'DBool', 19 => 'DBytes', 30 => 'DData', 10 => 'DDate', 11 => 'DDateTime', 20 => 'DEncoded', 31 => 'DEnum', 23 => 'DFlags', 7 => 'DFloat', 0 => 'DId', 1 => 'DInt', 32 => 'DInterval', 17 => 'DLongBinary', 28 => 'DMediumInt', 29 => 'DMediumUInt', 22 => 'DNekoSerialized', 33 => 'DNull', 21 => 'DSerialized', 6 => 'DSingle', 16 => 'DSmallBinary', 26 => 'DSmallInt', 14 => 'DSmallText', 27 => 'DSmallUInt', 9 => 'DString', 15 => 'DText', 12 => 'DTimeStamp', 24 => 'DTinyInt', 13 => 'DTinyText', 25 => 'DTinyUInt', 2 => 'DUId', 3 => 'DUInt');
	}
sys_db_XRecordType::$DBigId = new sys_db_XRecordType("DBigId", 4);
sys_db_XRecordType::$DBigInt = new sys_db_XRecordType("DBigInt", 5);
sys_db_XRecordType::$DBinary = new sys_db_XRecordType("DBinary", 18);
sys_db_XRecordType::$DBool = new sys_db_XRecordType("DBool", 8);
sys_db_XRecordType::$DData = new sys_db_XRecordType("DData", 30);
sys_db_XRecordType::$DDate = new sys_db_XRecordType("DDate", 10);
sys_db_XRecordType::$DDateTime = new sys_db_XRecordType("DDateTime", 11);
sys_db_XRecordType::$DEncoded = new sys_db_XRecordType("DEncoded", 20);
sys_db_XRecordType::$DFloat = new sys_db_XRecordType("DFloat", 7);
sys_db_XRecordType::$DId = new sys_db_XRecordType("DId", 0);
sys_db_XRecordType::$DInt = new sys_db_XRecordType("DInt", 1);
sys_db_XRecordType::$DInterval = new sys_db_XRecordType("DInterval", 32);
sys_db_XRecordType::$DLongBinary = new sys_db_XRecordType("DLongBinary", 17);
sys_db_XRecordType::$DMediumInt = new sys_db_XRecordType("DMediumInt", 28);
sys_db_XRecordType::$DMediumUInt = new sys_db_XRecordType("DMediumUInt", 29);
sys_db_XRecordType::$DNekoSerialized = new sys_db_XRecordType("DNekoSerialized", 22);
sys_db_XRecordType::$DNull = new sys_db_XRecordType("DNull", 33);
sys_db_XRecordType::$DSerialized = new sys_db_XRecordType("DSerialized", 21);
sys_db_XRecordType::$DSingle = new sys_db_XRecordType("DSingle", 6);
sys_db_XRecordType::$DSmallBinary = new sys_db_XRecordType("DSmallBinary", 16);
sys_db_XRecordType::$DSmallInt = new sys_db_XRecordType("DSmallInt", 26);
sys_db_XRecordType::$DSmallText = new sys_db_XRecordType("DSmallText", 14);
sys_db_XRecordType::$DSmallUInt = new sys_db_XRecordType("DSmallUInt", 27);
sys_db_XRecordType::$DText = new sys_db_XRecordType("DText", 15);
sys_db_XRecordType::$DTimeStamp = new sys_db_XRecordType("DTimeStamp", 12);
sys_db_XRecordType::$DTinyInt = new sys_db_XRecordType("DTinyInt", 24);
sys_db_XRecordType::$DTinyText = new sys_db_XRecordType("DTinyText", 13);
sys_db_XRecordType::$DTinyUInt = new sys_db_XRecordType("DTinyUInt", 25);
sys_db_XRecordType::$DUId = new sys_db_XRecordType("DUId", 2);
sys_db_XRecordType::$DUInt = new sys_db_XRecordType("DUInt", 3);
