<?php

class XLambda {
	public function __construct(){}
	static function map($it, $f) {
		$l = new XHList();
		if(null == $it) throw new HException('null iterable');
		$__hx__it = $it->iterator();
		while($__hx__it->hasNext()) {
			$x = $__hx__it->next();
			$l->add(call_user_func_array($f, array($x)));
		}
		return $l;
	}
	static function iter($it, $f) {
		if(null == $it) throw new HException('null iterable');
		$__hx__it = $it->iterator();
		while($__hx__it->hasNext()) {
			$x = $__hx__it->next();
			call_user_func_array($f, array($x));
		}
	}
	static function indexOf($it, $v) {
		$i = 0;
		if(null == $it) throw new HException('null iterable');
		$__hx__it = $it->iterator();
		while($__hx__it->hasNext()) {
			$v2 = $__hx__it->next();
			if($v == $v2) {
				return $i;
			}
			$i++;
		}
		return -1;
	}
	function __toString() { return 'Lambda'; }
}
