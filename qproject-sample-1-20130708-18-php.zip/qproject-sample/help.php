<?php
putenv("LANG=ru_RU.UTF-8");
setlocale(LC_ALL,"");
echo strftime("%A %d.%m.%y %H:%M");
?>
