(function () { "use strict";
var $hxClasses = {},$estr = function() { return js.Boot.__string_rec(this,''); };
function $extend(from, fields) {
	function inherit() {}; inherit.prototype = from; var proto = new inherit();
	for (var name in fields) proto[name] = fields[name];
	if( fields.toString !== Object.prototype.toString ) proto.toString = fields.toString;
	return proto;
}
var DateTools = function() { }
$hxClasses["DateTools"] = DateTools;
DateTools.__name__ = ["DateTools"];
DateTools.delta = function(d,t) {
	return (function($this) {
		var $r;
		var d1 = new Date();
		d1.setTime(d.getTime() + t);
		$r = d1;
		return $r;
	}(this));
}
var EReg = function(r,opt) {
	opt = opt.split("u").join("");
	this.r = new RegExp(r,opt);
};
$hxClasses["EReg"] = EReg;
EReg.__name__ = ["EReg"];
EReg.prototype = {
	matched: function(n) {
		return this.r.m != null && n >= 0 && n < this.r.m.length?this.r.m[n]:(function($this) {
			var $r;
			throw "EReg::matched";
			return $r;
		}(this));
	}
	,match: function(s) {
		if(this.r.global) this.r.lastIndex = 0;
		this.r.m = this.r.exec(s);
		this.r.s = s;
		return this.r.m != null;
	}
	,r: null
	,__class__: EReg
}
var HxOverrides = function() { }
$hxClasses["HxOverrides"] = HxOverrides;
HxOverrides.__name__ = ["HxOverrides"];
HxOverrides.dateStr = function(date) {
	var m = date.getMonth() + 1;
	var d = date.getDate();
	var h = date.getHours();
	var mi = date.getMinutes();
	var s = date.getSeconds();
	return date.getFullYear() + "-" + (m < 10?"0" + m:"" + m) + "-" + (d < 10?"0" + d:"" + d) + " " + (h < 10?"0" + h:"" + h) + ":" + (mi < 10?"0" + mi:"" + mi) + ":" + (s < 10?"0" + s:"" + s);
}
HxOverrides.strDate = function(s) {
	switch(s.length) {
	case 8:
		var k = s.split(":");
		var d = new Date();
		d.setTime(0);
		d.setUTCHours(k[0]);
		d.setUTCMinutes(k[1]);
		d.setUTCSeconds(k[2]);
		return d;
	case 10:
		var k = s.split("-");
		return new Date(k[0],k[1] - 1,k[2],0,0,0);
	case 19:
		var k = s.split(" ");
		var y = k[0].split("-");
		var t = k[1].split(":");
		return new Date(y[0],y[1] - 1,y[2],t[0],t[1],t[2]);
	default:
		throw "Invalid date format : " + s;
	}
}
HxOverrides.cca = function(s,index) {
	var x = s.charCodeAt(index);
	if(x != x) return undefined;
	return x;
}
HxOverrides.substr = function(s,pos,len) {
	if(pos != null && pos != 0 && len != null && len < 0) return "";
	if(len == null) len = s.length;
	if(pos < 0) {
		pos = s.length + pos;
		if(pos < 0) pos = 0;
	} else if(len < 0) len = s.length + len - pos;
	return s.substr(pos,len);
}
HxOverrides.remove = function(a,obj) {
	var i = 0;
	var l = a.length;
	while(i < l) {
		if(a[i] == obj) {
			a.splice(i,1);
			return true;
		}
		i++;
	}
	return false;
}
HxOverrides.iter = function(a) {
	return { cur : 0, arr : a, hasNext : function() {
		return this.cur < this.arr.length;
	}, next : function() {
		return this.arr[this.cur++];
	}};
}
var List = function() {
	this.length = 0;
};
$hxClasses["List"] = List;
List.__name__ = ["List"];
List.prototype = {
	iterator: function() {
		return { h : this.h, hasNext : function() {
			return this.h != null;
		}, next : function() {
			if(this.h == null) return null;
			var x = this.h[0];
			this.h = this.h[1];
			return x;
		}};
	}
	,add: function(item) {
		var x = [item];
		if(this.h == null) this.h = x; else this.q[1] = x;
		this.q = x;
		this.length++;
	}
	,length: null
	,q: null
	,h: null
	,__class__: List
}
var IMap = function() { }
$hxClasses["IMap"] = IMap;
IMap.__name__ = ["IMap"];
var Reflect = function() { }
$hxClasses["Reflect"] = Reflect;
Reflect.__name__ = ["Reflect"];
Reflect.hasField = function(o,field) {
	return Object.prototype.hasOwnProperty.call(o,field);
}
Reflect.field = function(o,field) {
	var v = null;
	try {
		v = o[field];
	} catch( e ) {
	}
	return v;
}
Reflect.fields = function(o) {
	var a = [];
	if(o != null) {
		var hasOwnProperty = Object.prototype.hasOwnProperty;
		for( var f in o ) {
		if(f != "__id__" && f != "hx__closures__" && hasOwnProperty.call(o,f)) a.push(f);
		}
	}
	return a;
}
Reflect.isFunction = function(f) {
	return typeof(f) == "function" && !(f.__name__ || f.__ename__);
}
Reflect.deleteField = function(o,field) {
	if(!Reflect.hasField(o,field)) return false;
	delete(o[field]);
	return true;
}
var Std = function() { }
$hxClasses["Std"] = Std;
Std.__name__ = ["Std"];
Std.string = function(s) {
	return js.Boot.__string_rec(s,"");
}
Std.parseFloat = function(x) {
	return parseFloat(x);
}
var StringBuf = function() {
	this.b = "";
};
$hxClasses["StringBuf"] = StringBuf;
StringBuf.__name__ = ["StringBuf"];
StringBuf.prototype = {
	b: null
	,__class__: StringBuf
}
var StringTools = function() { }
$hxClasses["StringTools"] = StringTools;
StringTools.__name__ = ["StringTools"];
StringTools.urlEncode = function(s) {
	return encodeURIComponent(s);
}
StringTools.urlDecode = function(s) {
	return decodeURIComponent(s.split("+").join(" "));
}
StringTools.htmlEscape = function(s,quotes) {
	s = s.split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;");
	return quotes?s.split("\"").join("&quot;").split("'").join("&#039;"):s;
}
StringTools.startsWith = function(s,start) {
	return s.length >= start.length && HxOverrides.substr(s,0,start.length) == start;
}
StringTools.isSpace = function(s,pos) {
	var c = HxOverrides.cca(s,pos);
	return c > 8 && c < 14 || c == 32;
}
StringTools.ltrim = function(s) {
	var l = s.length;
	var r = 0;
	while(r < l && StringTools.isSpace(s,r)) r++;
	if(r > 0) return HxOverrides.substr(s,r,l - r); else return s;
}
StringTools.rtrim = function(s) {
	var l = s.length;
	var r = 0;
	while(r < l && StringTools.isSpace(s,l - r - 1)) r++;
	if(r > 0) return HxOverrides.substr(s,0,l - r); else return s;
}
StringTools.replace = function(s,sub,by) {
	return s.split(sub).join(by);
}
var ValueType = $hxClasses["ValueType"] = { __ename__ : ["ValueType"], __constructs__ : ["TNull","TInt","TFloat","TBool","TObject","TFunction","TClass","TEnum","TUnknown"] }
ValueType.TNull = ["TNull",0];
ValueType.TNull.toString = $estr;
ValueType.TNull.__enum__ = ValueType;
ValueType.TInt = ["TInt",1];
ValueType.TInt.toString = $estr;
ValueType.TInt.__enum__ = ValueType;
ValueType.TFloat = ["TFloat",2];
ValueType.TFloat.toString = $estr;
ValueType.TFloat.__enum__ = ValueType;
ValueType.TBool = ["TBool",3];
ValueType.TBool.toString = $estr;
ValueType.TBool.__enum__ = ValueType;
ValueType.TObject = ["TObject",4];
ValueType.TObject.toString = $estr;
ValueType.TObject.__enum__ = ValueType;
ValueType.TFunction = ["TFunction",5];
ValueType.TFunction.toString = $estr;
ValueType.TFunction.__enum__ = ValueType;
ValueType.TClass = function(c) { var $x = ["TClass",6,c]; $x.__enum__ = ValueType; $x.toString = $estr; return $x; }
ValueType.TEnum = function(e) { var $x = ["TEnum",7,e]; $x.__enum__ = ValueType; $x.toString = $estr; return $x; }
ValueType.TUnknown = ["TUnknown",8];
ValueType.TUnknown.toString = $estr;
ValueType.TUnknown.__enum__ = ValueType;
var Type = function() { }
$hxClasses["Type"] = Type;
Type.__name__ = ["Type"];
Type.getClass = function(o) {
	if(o == null) return null;
	return o.__class__;
}
Type.getClassName = function(c) {
	var a = c.__name__;
	return a.join(".");
}
Type.getEnumName = function(e) {
	var a = e.__ename__;
	return a.join(".");
}
Type.resolveClass = function(name) {
	var cl = $hxClasses[name];
	if(cl == null || !cl.__name__) return null;
	return cl;
}
Type.resolveEnum = function(name) {
	var e = $hxClasses[name];
	if(e == null || !e.__ename__) return null;
	return e;
}
Type.createEmptyInstance = function(cl) {
	function empty() {}; empty.prototype = cl.prototype;
	return new empty();
}
Type.createEnum = function(e,constr,params) {
	var f = Reflect.field(e,constr);
	if(f == null) throw "No such constructor " + constr;
	if(Reflect.isFunction(f)) {
		if(params == null) throw "Constructor " + constr + " need parameters";
		return f.apply(e,params);
	}
	if(params != null && params.length != 0) throw "Constructor " + constr + " does not need parameters";
	return f;
}
Type.getInstanceFields = function(c) {
	var a = [];
	for(var i in c.prototype) a.push(i);
	HxOverrides.remove(a,"__class__");
	HxOverrides.remove(a,"__properties__");
	return a;
}
Type.getEnumConstructs = function(e) {
	var a = e.__constructs__;
	return a.slice();
}
Type["typeof"] = function(v) {
	var _g = typeof(v);
	switch(_g) {
	case "boolean":
		return ValueType.TBool;
	case "string":
		return ValueType.TClass(String);
	case "number":
		if(Math.ceil(v) == v % 2147483648.0) return ValueType.TInt;
		return ValueType.TFloat;
	case "object":
		if(v == null) return ValueType.TNull;
		var e = v.__enum__;
		if(e != null) return ValueType.TEnum(e);
		var c = v.__class__;
		if(c != null) return ValueType.TClass(c);
		return ValueType.TObject;
	case "function":
		if(v.__name__ || v.__ename__) return ValueType.TObject;
		return ValueType.TFunction;
	case "undefined":
		return ValueType.TNull;
	default:
		return ValueType.TUnknown;
	}
}
var haxe = {}
haxe.StackItem = $hxClasses["haxe.StackItem"] = { __ename__ : ["haxe","StackItem"], __constructs__ : ["CFunction","Module","FilePos","Method","Lambda"] }
haxe.StackItem.CFunction = ["CFunction",0];
haxe.StackItem.CFunction.toString = $estr;
haxe.StackItem.CFunction.__enum__ = haxe.StackItem;
haxe.StackItem.Module = function(m) { var $x = ["Module",1,m]; $x.__enum__ = haxe.StackItem; $x.toString = $estr; return $x; }
haxe.StackItem.FilePos = function(s,file,line) { var $x = ["FilePos",2,s,file,line]; $x.__enum__ = haxe.StackItem; $x.toString = $estr; return $x; }
haxe.StackItem.Method = function(classname,method) { var $x = ["Method",3,classname,method]; $x.__enum__ = haxe.StackItem; $x.toString = $estr; return $x; }
haxe.StackItem.Lambda = function(v) { var $x = ["Lambda",4,v]; $x.__enum__ = haxe.StackItem; $x.toString = $estr; return $x; }
haxe.CallStack = function() { }
$hxClasses["haxe.CallStack"] = haxe.CallStack;
haxe.CallStack.__name__ = ["haxe","CallStack"];
haxe.CallStack.exceptionStack = function() {
	return [];
}
haxe.CallStack.toString = function(stack) {
	var b = new StringBuf();
	var _g = 0;
	while(_g < stack.length) {
		var s = stack[_g];
		++_g;
		b.b += "\nCalled from ";
		haxe.CallStack.itemToString(b,s);
	}
	return b.b;
}
haxe.CallStack.itemToString = function(b,s) {
	var $e = (s);
	switch( $e[1] ) {
	case 0:
		b.b += "a C function";
		break;
	case 1:
		var m = $e[2];
		b.b += "module ";
		b.b += Std.string(m);
		break;
	case 2:
		var line = $e[4], file = $e[3], s1 = $e[2];
		if(s1 != null) {
			haxe.CallStack.itemToString(b,s1);
			b.b += " (";
		}
		b.b += Std.string(file);
		b.b += " line ";
		b.b += Std.string(line);
		if(s1 != null) b.b += ")";
		break;
	case 3:
		var meth = $e[3], cname = $e[2];
		b.b += Std.string(cname);
		b.b += ".";
		b.b += Std.string(meth);
		break;
	case 4:
		var n = $e[2];
		b.b += "local function #";
		b.b += Std.string(n);
		break;
	}
}
haxe.Http = function(url) {
	this.url = url;
	this.headers = new haxe.ds.StringMap();
	this.params = new haxe.ds.StringMap();
	this.async = true;
};
$hxClasses["haxe.Http"] = haxe.Http;
haxe.Http.__name__ = ["haxe","Http"];
haxe.Http.prototype = {
	onStatus: function(status) {
	}
	,onError: function(msg) {
	}
	,onData: function(data) {
	}
	,request: function(post) {
		var me = this;
		me.responseData = null;
		var r = js.Browser.createXMLHttpRequest();
		var onreadystatechange = function(_) {
			if(r.readyState != 4) return;
			var s = (function($this) {
				var $r;
				try {
					$r = r.status;
				} catch( e ) {
					$r = null;
				}
				return $r;
			}(this));
			if(s == undefined) s = null;
			if(s != null) me.onStatus(s);
			if(s != null && s >= 200 && s < 400) me.onData(me.responseData = r.responseText); else if(s == null) me.onError("Failed to connect or resolve host"); else switch(s) {
			case 12029:
				me.onError("Failed to connect to host");
				break;
			case 12007:
				me.onError("Unknown host");
				break;
			default:
				me.responseData = r.responseText;
				me.onError("Http Error #" + r.status);
			}
		};
		if(this.async) r.onreadystatechange = onreadystatechange;
		var uri = this.postData;
		if(uri != null) post = true; else {
			var $it0 = this.params.keys();
			while( $it0.hasNext() ) {
				var p = $it0.next();
				if(uri == null) uri = ""; else uri += "&";
				uri += StringTools.urlEncode(p) + "=" + StringTools.urlEncode(this.params.get(p));
			}
		}
		try {
			if(post) r.open("POST",this.url,this.async); else if(uri != null) {
				var question = this.url.split("?").length <= 1;
				r.open("GET",this.url + (question?"?":"&") + uri,this.async);
				uri = null;
			} else r.open("GET",this.url,this.async);
		} catch( e ) {
			this.onError(e.toString());
			return;
		}
		if(this.headers.get("Content-Type") == null && post && this.postData == null) r.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		var $it1 = this.headers.keys();
		while( $it1.hasNext() ) {
			var h = $it1.next();
			r.setRequestHeader(h,this.headers.get(h));
		}
		r.send(uri);
		if(!this.async) onreadystatechange(null);
	}
	,setParameter: function(param,value) {
		this.params.set(param,value);
		return this;
	}
	,setHeader: function(header,value) {
		this.headers.set(header,value);
		return this;
	}
	,params: null
	,headers: null
	,postData: null
	,async: null
	,responseData: null
	,url: null
	,__class__: haxe.Http
}
haxe.Log = function() { }
$hxClasses["haxe.Log"] = haxe.Log;
haxe.Log.__name__ = ["haxe","Log"];
haxe.Log.trace = function(v,infos) {
	js.Boot.__trace(v,infos);
}
haxe.Serializer = function() {
	this.buf = new StringBuf();
	this.cache = new Array();
	this.useCache = haxe.Serializer.USE_CACHE;
	this.useEnumIndex = haxe.Serializer.USE_ENUM_INDEX;
	this.shash = new haxe.ds.StringMap();
	this.scount = 0;
};
$hxClasses["haxe.Serializer"] = haxe.Serializer;
haxe.Serializer.__name__ = ["haxe","Serializer"];
haxe.Serializer.run = function(v) {
	var s = new haxe.Serializer();
	s.serialize(v);
	return s.toString();
}
haxe.Serializer.prototype = {
	serializeException: function(e) {
		this.buf.b += "x";
		this.serialize(e);
	}
	,serialize: function(v) {
		var _g = Type["typeof"](v);
		var $e = (_g);
		switch( $e[1] ) {
		case 0:
			this.buf.b += "n";
			break;
		case 1:
			if(v == 0) {
				this.buf.b += "z";
				return;
			}
			this.buf.b += "i";
			this.buf.b += Std.string(v);
			break;
		case 2:
			if(Math.isNaN(v)) this.buf.b += "k"; else if(!Math.isFinite(v)) this.buf.b += Std.string(v < 0?"m":"p"); else {
				this.buf.b += "d";
				this.buf.b += Std.string(v);
			}
			break;
		case 3:
			this.buf.b += Std.string(v?"t":"f");
			break;
		case 6:
			var c = $e[2];
			if(c == String) {
				this.serializeString(v);
				return;
			}
			if(this.useCache && this.serializeRef(v)) return;
			switch(c) {
			case Array:
				var ucount = 0;
				this.buf.b += "a";
				var l = v.length;
				var _g1 = 0;
				while(_g1 < l) {
					var i = _g1++;
					if(v[i] == null) ucount++; else {
						if(ucount > 0) {
							if(ucount == 1) this.buf.b += "n"; else {
								this.buf.b += "u";
								this.buf.b += Std.string(ucount);
							}
							ucount = 0;
						}
						this.serialize(v[i]);
					}
				}
				if(ucount > 0) {
					if(ucount == 1) this.buf.b += "n"; else {
						this.buf.b += "u";
						this.buf.b += Std.string(ucount);
					}
				}
				this.buf.b += "h";
				break;
			case List:
				this.buf.b += "l";
				var v1 = v;
				var $it0 = v1.iterator();
				while( $it0.hasNext() ) {
					var i = $it0.next();
					this.serialize(i);
				}
				this.buf.b += "h";
				break;
			case Date:
				var d = v;
				this.buf.b += "v";
				this.buf.b += Std.string(HxOverrides.dateStr(d));
				break;
			case haxe.ds.StringMap:
				this.buf.b += "b";
				var v1 = v;
				var $it1 = v1.keys();
				while( $it1.hasNext() ) {
					var k = $it1.next();
					this.serializeString(k);
					this.serialize(v1.get(k));
				}
				this.buf.b += "h";
				break;
			case haxe.ds.IntMap:
				this.buf.b += "q";
				var v1 = v;
				var $it2 = v1.keys();
				while( $it2.hasNext() ) {
					var k = $it2.next();
					this.buf.b += ":";
					this.buf.b += Std.string(k);
					this.serialize(v1.get(k));
				}
				this.buf.b += "h";
				break;
			case haxe.ds.ObjectMap:
				this.buf.b += "M";
				var v1 = v;
				var $it3 = v1.keys();
				while( $it3.hasNext() ) {
					var k = $it3.next();
					var id = Reflect.field(k,"__id__");
					Reflect.deleteField(k,"__id__");
					this.serialize(k);
					k.__id__ = id;
					this.serialize(v1.h[k.__id__]);
				}
				this.buf.b += "h";
				break;
			case haxe.io.Bytes:
				var v1 = v;
				var i = 0;
				var max = v1.length - 2;
				var charsBuf = new StringBuf();
				var b64 = haxe.Serializer.BASE64;
				while(i < max) {
					var b1 = v1.b[i++];
					var b2 = v1.b[i++];
					var b3 = v1.b[i++];
					charsBuf.b += Std.string(b64.charAt(b1 >> 2));
					charsBuf.b += Std.string(b64.charAt((b1 << 4 | b2 >> 4) & 63));
					charsBuf.b += Std.string(b64.charAt((b2 << 2 | b3 >> 6) & 63));
					charsBuf.b += Std.string(b64.charAt(b3 & 63));
				}
				if(i == max) {
					var b1 = v1.b[i++];
					var b2 = v1.b[i++];
					charsBuf.b += Std.string(b64.charAt(b1 >> 2));
					charsBuf.b += Std.string(b64.charAt((b1 << 4 | b2 >> 4) & 63));
					charsBuf.b += Std.string(b64.charAt(b2 << 2 & 63));
				} else if(i == max + 1) {
					var b1 = v1.b[i++];
					charsBuf.b += Std.string(b64.charAt(b1 >> 2));
					charsBuf.b += Std.string(b64.charAt(b1 << 4 & 63));
				}
				var chars = charsBuf.b;
				this.buf.b += "s";
				this.buf.b += Std.string(chars.length);
				this.buf.b += ":";
				this.buf.b += Std.string(chars);
				break;
			default:
				this.cache.pop();
				if(v.hxSerialize != null) {
					this.buf.b += "C";
					this.serializeString(Type.getClassName(c));
					this.cache.push(v);
					v.hxSerialize(this);
					this.buf.b += "g";
				} else {
					this.buf.b += "c";
					this.serializeString(Type.getClassName(c));
					this.cache.push(v);
					this.serializeFields(v);
				}
			}
			break;
		case 4:
			if(this.useCache && this.serializeRef(v)) return;
			this.buf.b += "o";
			this.serializeFields(v);
			break;
		case 7:
			var e = $e[2];
			if(this.useCache && this.serializeRef(v)) return;
			this.cache.pop();
			this.buf.b += Std.string(this.useEnumIndex?"j":"w");
			this.serializeString(Type.getEnumName(e));
			if(this.useEnumIndex) {
				this.buf.b += ":";
				this.buf.b += Std.string(v[1]);
			} else this.serializeString(v[0]);
			this.buf.b += ":";
			var l = v.length;
			this.buf.b += Std.string(l - 2);
			var _g1 = 2;
			while(_g1 < l) {
				var i = _g1++;
				this.serialize(v[i]);
			}
			this.cache.push(v);
			break;
		case 5:
			throw "Cannot serialize function";
			break;
		default:
			throw "Cannot serialize " + Std.string(v);
		}
	}
	,serializeFields: function(v) {
		var _g = 0, _g1 = Reflect.fields(v);
		while(_g < _g1.length) {
			var f = _g1[_g];
			++_g;
			this.serializeString(f);
			this.serialize(Reflect.field(v,f));
		}
		this.buf.b += "g";
	}
	,serializeRef: function(v) {
		var vt = typeof(v);
		var _g1 = 0, _g = this.cache.length;
		while(_g1 < _g) {
			var i = _g1++;
			var ci = this.cache[i];
			if(typeof(ci) == vt && ci == v) {
				this.buf.b += "r";
				this.buf.b += Std.string(i);
				return true;
			}
		}
		this.cache.push(v);
		return false;
	}
	,serializeString: function(s) {
		var x = this.shash.get(s);
		if(x != null) {
			this.buf.b += "R";
			this.buf.b += Std.string(x);
			return;
		}
		this.shash.set(s,this.scount++);
		this.buf.b += "y";
		s = StringTools.urlEncode(s);
		this.buf.b += Std.string(s.length);
		this.buf.b += ":";
		this.buf.b += Std.string(s);
	}
	,toString: function() {
		return this.buf.b;
	}
	,useEnumIndex: null
	,useCache: null
	,scount: null
	,shash: null
	,cache: null
	,buf: null
	,__class__: haxe.Serializer
}
haxe.Unserializer = function(buf) {
	this.buf = buf;
	this.length = buf.length;
	this.pos = 0;
	this.scache = new Array();
	this.cache = new Array();
	var r = haxe.Unserializer.DEFAULT_RESOLVER;
	if(r == null) {
		r = Type;
		haxe.Unserializer.DEFAULT_RESOLVER = r;
	}
	this.setResolver(r);
};
$hxClasses["haxe.Unserializer"] = haxe.Unserializer;
haxe.Unserializer.__name__ = ["haxe","Unserializer"];
haxe.Unserializer.initCodes = function() {
	var codes = new Array();
	var _g1 = 0, _g = haxe.Unserializer.BASE64.length;
	while(_g1 < _g) {
		var i = _g1++;
		codes[haxe.Unserializer.BASE64.charCodeAt(i)] = i;
	}
	return codes;
}
haxe.Unserializer.run = function(v) {
	return new haxe.Unserializer(v).unserialize();
}
haxe.Unserializer.prototype = {
	unserialize: function() {
		var _g = this.buf.charCodeAt(this.pos++);
		switch(_g) {
		case 110:
			return null;
		case 116:
			return true;
		case 102:
			return false;
		case 122:
			return 0;
		case 105:
			return this.readDigits();
		case 100:
			var p1 = this.pos;
			while(true) {
				var c = this.buf.charCodeAt(this.pos);
				if(c >= 43 && c < 58 || c == 101 || c == 69) this.pos++; else break;
			}
			return Std.parseFloat(HxOverrides.substr(this.buf,p1,this.pos - p1));
		case 121:
			var len = this.readDigits();
			if(this.buf.charCodeAt(this.pos++) != 58 || this.length - this.pos < len) throw "Invalid string length";
			var s = HxOverrides.substr(this.buf,this.pos,len);
			this.pos += len;
			s = StringTools.urlDecode(s);
			this.scache.push(s);
			return s;
		case 107:
			return Math.NaN;
		case 109:
			return Math.NEGATIVE_INFINITY;
		case 112:
			return Math.POSITIVE_INFINITY;
		case 97:
			var buf = this.buf;
			var a = new Array();
			this.cache.push(a);
			while(true) {
				var c = this.buf.charCodeAt(this.pos);
				if(c == 104) {
					this.pos++;
					break;
				}
				if(c == 117) {
					this.pos++;
					var n = this.readDigits();
					a[a.length + n - 1] = null;
				} else a.push(this.unserialize());
			}
			return a;
		case 111:
			var o = { };
			this.cache.push(o);
			this.unserializeObject(o);
			return o;
		case 114:
			var n = this.readDigits();
			if(n < 0 || n >= this.cache.length) throw "Invalid reference";
			return this.cache[n];
		case 82:
			var n = this.readDigits();
			if(n < 0 || n >= this.scache.length) throw "Invalid string reference";
			return this.scache[n];
		case 120:
			throw this.unserialize();
			break;
		case 99:
			var name = this.unserialize();
			var cl = this.resolver.resolveClass(name);
			if(cl == null) cl = Type.resolveClass(name);
			if(cl == null) throw "xClass not found " + name;
			var o = Type.createEmptyInstance(cl);
			this.cache.push(o);
			this.unserializeObject(o);
			return o;
		case 119:
			var name = this.unserialize();
			var edecl = this.resolver.resolveEnum(name);
			if(edecl == null) edecl = Type.resolveEnum(name);
			if(edecl == null) throw "Enum2 not found " + name;
			var e = this.unserializeEnum(edecl,this.unserialize());
			this.cache.push(e);
			return e;
		case 106:
			var name = this.unserialize();
			var edecl = this.resolver.resolveEnum(name);
			if(edecl == null) edecl = Type.resolveEnum(name);
			if(edecl == null) throw "Enum3 not found " + name;
			this.pos++;
			var index = this.readDigits();
			var tag = Type.getEnumConstructs(edecl)[index];
			if(tag == null) throw "Unknown enum index " + name + "@" + index;
			var e = this.unserializeEnum(edecl,tag);
			this.cache.push(e);
			return e;
		case 108:
			var l = new List();
			this.cache.push(l);
			var buf = this.buf;
			while(this.buf.charCodeAt(this.pos) != 104) l.add(this.unserialize());
			this.pos++;
			return l;
		case 98:
			var h = new haxe.ds.StringMap();
			this.cache.push(h);
			var buf = this.buf;
			while(this.buf.charCodeAt(this.pos) != 104) {
				var s = this.unserialize();
				h.set(s,this.unserialize());
			}
			this.pos++;
			return h;
		case 113:
			var h = new haxe.ds.IntMap();
			this.cache.push(h);
			var buf = this.buf;
			var c = this.buf.charCodeAt(this.pos++);
			while(c == 58) {
				var i = this.readDigits();
				h.set(i,this.unserialize());
				c = this.buf.charCodeAt(this.pos++);
			}
			if(c != 104) throw "Invalid IntMap format";
			return h;
		case 77:
			var h = new haxe.ds.ObjectMap();
			this.cache.push(h);
			var buf = this.buf;
			while(this.buf.charCodeAt(this.pos) != 104) {
				var s = this.unserialize();
				h.set(s,this.unserialize());
			}
			this.pos++;
			return h;
		case 118:
			var d = HxOverrides.strDate(HxOverrides.substr(this.buf,this.pos,19));
			this.cache.push(d);
			this.pos += 19;
			return d;
		case 115:
			var len = this.readDigits();
			var buf = this.buf;
			if(this.buf.charCodeAt(this.pos++) != 58 || this.length - this.pos < len) throw "Invalid bytes length";
			var codes = haxe.Unserializer.CODES;
			if(codes == null) {
				codes = haxe.Unserializer.initCodes();
				haxe.Unserializer.CODES = codes;
			}
			var i = this.pos;
			var rest = len & 3;
			var size = (len >> 2) * 3 + (rest >= 2?rest - 1:0);
			var max = i + (len - rest);
			var bytes = haxe.io.Bytes.alloc(size);
			var bpos = 0;
			while(i < max) {
				var c1 = codes[buf.charCodeAt(i++)];
				var c2 = codes[buf.charCodeAt(i++)];
				bytes.b[bpos++] = (c1 << 2 | c2 >> 4) & 255;
				var c3 = codes[buf.charCodeAt(i++)];
				bytes.b[bpos++] = (c2 << 4 | c3 >> 2) & 255;
				var c4 = codes[buf.charCodeAt(i++)];
				bytes.b[bpos++] = (c3 << 6 | c4) & 255;
			}
			if(rest >= 2) {
				var c1 = codes[buf.charCodeAt(i++)];
				var c2 = codes[buf.charCodeAt(i++)];
				bytes.b[bpos++] = (c1 << 2 | c2 >> 4) & 255;
				if(rest == 3) {
					var c3 = codes[buf.charCodeAt(i++)];
					bytes.b[bpos++] = (c2 << 4 | c3 >> 2) & 255;
				}
			}
			this.pos += len;
			this.cache.push(bytes);
			return bytes;
		case 67:
			var name = this.unserialize();
			var cl = this.resolver.resolveClass(name);
			if(cl == null) throw "Class not found " + name;
			var o = Type.createEmptyInstance(cl);
			this.cache.push(o);
			o.hxUnserialize(this);
			if(this.buf.charCodeAt(this.pos++) != 103) throw "Invalid custom data";
			return o;
		default:
		}
		this.pos--;
		throw "Invalid char " + this.buf.charAt(this.pos) + " at position " + this.pos;
	}
	,unserializeEnum: function(edecl,tag) {
		if(this.buf.charCodeAt(this.pos++) != 58) throw "Invalid enum format";
		var nargs = this.readDigits();
		if(nargs == 0) return Type.createEnum(edecl,tag);
		var args = new Array();
		while(nargs-- > 0) args.push(this.unserialize());
		return Type.createEnum(edecl,tag,args);
	}
	,unserializeObject: function(o) {
		while(true) {
			if(this.pos >= this.length) throw "Invalid object";
			if(this.buf.charCodeAt(this.pos) == 103) break;
			var k = this.unserialize();
			if(!js.Boot.__instanceof(k,String)) throw "Invalid object key";
			var v = this.unserialize();
			o[k] = v;
		}
		this.pos++;
	}
	,readDigits: function() {
		var k = 0;
		var s = false;
		var fpos = this.pos;
		while(true) {
			var c = this.buf.charCodeAt(this.pos);
			if(c != c) break;
			if(c == 45) {
				if(this.pos != fpos) break;
				s = true;
				this.pos++;
				continue;
			}
			if(c < 48 || c > 57) break;
			k = k * 10 + (c - 48);
			this.pos++;
		}
		if(s) k *= -1;
		return k;
	}
	,get: function(p) {
		return this.buf.charCodeAt(p);
	}
	,getResolver: function() {
		return this.resolver;
	}
	,setResolver: function(r) {
		if(r == null) this.resolver = { resolveClass : function(_) {
			return null;
		}, resolveEnum : function(_) {
			return null;
		}}; else this.resolver = r;
	}
	,resolver: null
	,scache: null
	,cache: null
	,length: null
	,pos: null
	,buf: null
	,__class__: haxe.Unserializer
}
haxe.ds = {}
haxe.ds.IntMap = function() {
	this.h = { };
};
$hxClasses["haxe.ds.IntMap"] = haxe.ds.IntMap;
haxe.ds.IntMap.__name__ = ["haxe","ds","IntMap"];
haxe.ds.IntMap.__interfaces__ = [IMap];
haxe.ds.IntMap.prototype = {
	keys: function() {
		var a = [];
		for( var key in this.h ) {
		if(this.h.hasOwnProperty(key)) a.push(key | 0);
		}
		return HxOverrides.iter(a);
	}
	,get: function(key) {
		return this.h[key];
	}
	,set: function(key,value) {
		this.h[key] = value;
	}
	,h: null
	,__class__: haxe.ds.IntMap
}
haxe.ds.ObjectMap = function() {
	this.h = { };
	this.h.__keys__ = { };
};
$hxClasses["haxe.ds.ObjectMap"] = haxe.ds.ObjectMap;
haxe.ds.ObjectMap.__name__ = ["haxe","ds","ObjectMap"];
haxe.ds.ObjectMap.__interfaces__ = [IMap];
haxe.ds.ObjectMap.prototype = {
	keys: function() {
		var a = [];
		for( var key in this.h.__keys__ ) {
		if(this.h.hasOwnProperty(key)) a.push(this.h.__keys__[key]);
		}
		return HxOverrides.iter(a);
	}
	,set: function(key,value) {
		var id = key.__id__ != null?key.__id__:key.__id__ = ++haxe.ds.ObjectMap.count;
		this.h[id] = value;
		this.h.__keys__[id] = key;
	}
	,h: null
	,__class__: haxe.ds.ObjectMap
}
haxe.ds.StringMap = function() {
	this.h = { };
};
$hxClasses["haxe.ds.StringMap"] = haxe.ds.StringMap;
haxe.ds.StringMap.__name__ = ["haxe","ds","StringMap"];
haxe.ds.StringMap.__interfaces__ = [IMap];
haxe.ds.StringMap.prototype = {
	keys: function() {
		var a = [];
		for( var key in this.h ) {
		if(this.h.hasOwnProperty(key)) a.push(key.substr(1));
		}
		return HxOverrides.iter(a);
	}
	,get: function(key) {
		return this.h["$" + key];
	}
	,set: function(key,value) {
		this.h["$" + key] = value;
	}
	,h: null
	,__class__: haxe.ds.StringMap
}
haxe.io = {}
haxe.io.Bytes = function(length,b) {
	this.length = length;
	this.b = b;
};
$hxClasses["haxe.io.Bytes"] = haxe.io.Bytes;
haxe.io.Bytes.__name__ = ["haxe","io","Bytes"];
haxe.io.Bytes.alloc = function(length) {
	var a = new Array();
	var _g = 0;
	while(_g < length) {
		var i = _g++;
		a.push(0);
	}
	return new haxe.io.Bytes(length,a);
}
haxe.io.Bytes.prototype = {
	b: null
	,length: null
	,__class__: haxe.io.Bytes
}
haxe.remoting = {}
haxe.remoting.AsyncConnection = function() { }
$hxClasses["haxe.remoting.AsyncConnection"] = haxe.remoting.AsyncConnection;
haxe.remoting.AsyncConnection.__name__ = ["haxe","remoting","AsyncConnection"];
haxe.remoting.AsyncConnection.prototype = {
	setErrorHandler: null
	,call: null
	,resolve: null
	,__class__: haxe.remoting.AsyncConnection
}
haxe.remoting.Connection = function() { }
$hxClasses["haxe.remoting.Connection"] = haxe.remoting.Connection;
haxe.remoting.Connection.__name__ = ["haxe","remoting","Connection"];
haxe.remoting.Connection.prototype = {
	call: null
	,resolve: null
	,__class__: haxe.remoting.Connection
}
haxe.remoting.HttpAsyncConnection = function(data,path) {
	this.__data = data;
	this.__path = path;
};
$hxClasses["haxe.remoting.HttpAsyncConnection"] = haxe.remoting.HttpAsyncConnection;
haxe.remoting.HttpAsyncConnection.__name__ = ["haxe","remoting","HttpAsyncConnection"];
haxe.remoting.HttpAsyncConnection.__interfaces__ = [haxe.remoting.AsyncConnection];
haxe.remoting.HttpAsyncConnection.urlConnect = function(url) {
	return new haxe.remoting.HttpAsyncConnection({ url : url, error : function(e) {
		throw e;
	}},[]);
}
haxe.remoting.HttpAsyncConnection.prototype = {
	call: function(params,onResult) {
		var h = new haxe.Http(this.__data.url);
		var s = new haxe.Serializer();
		s.serialize(this.__path);
		s.serialize(params);
		h.setHeader("X-Haxe-Remoting","1");
		h.setParameter("__x",s.toString());
		var error = this.__data.error;
		h.onData = function(response) {
			var ok = true;
			var ret;
			try {
				if(HxOverrides.substr(response,0,3) != "hxr") throw "Invalid response : '" + response + "'";
				var s1 = new haxe.Unserializer(HxOverrides.substr(response,3,null));
				ret = s1.unserialize();
			} catch( err ) {
				ret = null;
				ok = false;
				error(err);
			}
			if(ok && onResult != null) onResult(ret);
		};
		h.onError = error;
		h.request(true);
	}
	,setErrorHandler: function(h) {
		this.__data.error = h;
	}
	,resolve: function(name) {
		var c = new haxe.remoting.HttpAsyncConnection(this.__data,this.__path.slice());
		c.__path.push(name);
		return c;
	}
	,__path: null
	,__data: null
	,__class__: haxe.remoting.HttpAsyncConnection
}
haxe.remoting.HttpConnection = function(url,path) {
	this.__url = url;
	this.__path = path;
};
$hxClasses["haxe.remoting.HttpConnection"] = haxe.remoting.HttpConnection;
haxe.remoting.HttpConnection.__name__ = ["haxe","remoting","HttpConnection"];
haxe.remoting.HttpConnection.__interfaces__ = [haxe.remoting.Connection];
haxe.remoting.HttpConnection.urlConnect = function(url) {
	return new haxe.remoting.HttpConnection(url,[]);
}
haxe.remoting.HttpConnection.prototype = {
	call: function(params) {
		var data = null;
		var h = new haxe.Http(this.__url);
		h.async = false;
		var s = new haxe.Serializer();
		s.serialize(this.__path);
		s.serialize(params);
		h.setHeader("X-Haxe-Remoting","1");
		h.setParameter("__x",s.toString());
		h.onData = function(d) {
			data = d;
		};
		h.onError = function(e) {
			throw e;
		};
		h.request(true);
		if(HxOverrides.substr(data,0,3) != "hxr") throw "Invalid response : '" + data + "'";
		data = HxOverrides.substr(data,3,null);
		return new haxe.Unserializer(data).unserialize();
	}
	,resolve: function(name) {
		var c = new haxe.remoting.HttpConnection(this.__url,this.__path.slice());
		c.__path.push(name);
		return c;
	}
	,__path: null
	,__url: null
	,__class__: haxe.remoting.HttpConnection
}
haxe.unit = {}
haxe.unit.TestCase = function() {
};
$hxClasses["haxe.unit.TestCase"] = haxe.unit.TestCase;
haxe.unit.TestCase.__name__ = ["haxe","unit","TestCase"];
haxe.unit.TestCase.prototype = {
	assertEquals: function(expected,actual,c) {
		this.currentTest.done = true;
		if(actual != expected) {
			this.currentTest.success = false;
			this.currentTest.error = "expected '" + Std.string(expected) + "' but was '" + Std.string(actual) + "'";
			this.currentTest.posInfos = c;
			throw this.currentTest;
		}
	}
	,assertFalse: function(b,c) {
		this.currentTest.done = true;
		if(b == true) {
			this.currentTest.success = false;
			this.currentTest.error = "expected false but was true";
			this.currentTest.posInfos = c;
			throw this.currentTest;
		}
	}
	,assertTrue: function(b,c) {
		this.currentTest.done = true;
		if(b == false) {
			this.currentTest.success = false;
			this.currentTest.error = "expected true but was false";
			this.currentTest.posInfos = c;
			throw this.currentTest;
		}
	}
	,print: function(v) {
		haxe.unit.TestRunner.print(v);
	}
	,tearDown: function() {
	}
	,setup: function() {
	}
	,currentTest: null
	,__class__: haxe.unit.TestCase
}
haxe.unit.TestResult = function() {
	this.m_tests = new List();
	this.success = true;
};
$hxClasses["haxe.unit.TestResult"] = haxe.unit.TestResult;
haxe.unit.TestResult.__name__ = ["haxe","unit","TestResult"];
haxe.unit.TestResult.prototype = {
	toString: function() {
		var buf = new StringBuf();
		var failures = 0;
		var $it0 = this.m_tests.iterator();
		while( $it0.hasNext() ) {
			var test = $it0.next();
			if(test.success == false) {
				buf.b += "* ";
				buf.b += Std.string(test.classname);
				buf.b += "::";
				buf.b += Std.string(test.method);
				buf.b += "()";
				buf.b += "\n";
				buf.b += "ERR: ";
				if(test.posInfos != null) {
					buf.b += Std.string(test.posInfos.fileName);
					buf.b += ":";
					buf.b += Std.string(test.posInfos.lineNumber);
					buf.b += "(";
					buf.b += Std.string(test.posInfos.className);
					buf.b += ".";
					buf.b += Std.string(test.posInfos.methodName);
					buf.b += ") - ";
				}
				buf.b += Std.string(test.error);
				buf.b += "\n";
				if(test.backtrace != null) {
					buf.b += Std.string(test.backtrace);
					buf.b += "\n";
				}
				buf.b += "\n";
				failures++;
			}
		}
		buf.b += "\n";
		if(failures == 0) buf.b += "OK "; else buf.b += "FAILED ";
		buf.b += Std.string(this.m_tests.length);
		buf.b += " tests, ";
		buf.b += Std.string(failures);
		buf.b += " failed, ";
		buf.b += Std.string(this.m_tests.length - failures);
		buf.b += " success";
		buf.b += "\n";
		return buf.b;
	}
	,add: function(t) {
		this.m_tests.add(t);
		if(!t.success) this.success = false;
	}
	,success: null
	,m_tests: null
	,__class__: haxe.unit.TestResult
}
haxe.unit.TestRunner = function() {
	this.result = new haxe.unit.TestResult();
	this.cases = new List();
};
$hxClasses["haxe.unit.TestRunner"] = haxe.unit.TestRunner;
haxe.unit.TestRunner.__name__ = ["haxe","unit","TestRunner"];
haxe.unit.TestRunner.print = function(v) {
	var msg = StringTools.htmlEscape(js.Boot.__string_rec(v,"")).split("\n").join("<br/>");
	var d = document.getElementById("haxe:trace");
	if(d == null) alert("haxe:trace element not found"); else d.innerHTML += msg;
}
haxe.unit.TestRunner.customTrace = function(v,p) {
	haxe.unit.TestRunner.print(p.fileName + ":" + p.lineNumber + ": " + Std.string(v) + "\n");
}
haxe.unit.TestRunner.prototype = {
	runCase: function(t) {
		var old = haxe.Log.trace;
		haxe.Log.trace = haxe.unit.TestRunner.customTrace;
		var cl = Type.getClass(t);
		var fields = Type.getInstanceFields(cl);
		haxe.unit.TestRunner.print("Class: " + Type.getClassName(cl) + " ");
		var _g = 0;
		while(_g < fields.length) {
			var f = fields[_g];
			++_g;
			var fname = f;
			var field = Reflect.field(t,f);
			if(StringTools.startsWith(fname,"test") && Reflect.isFunction(field)) {
				t.currentTest = new haxe.unit.TestStatus();
				t.currentTest.classname = Type.getClassName(cl);
				t.currentTest.method = fname;
				t.setup();
				try {
					field.apply(t,new Array());
					if(t.currentTest.done) {
						t.currentTest.success = true;
						haxe.unit.TestRunner.print(".");
					} else {
						t.currentTest.success = false;
						t.currentTest.error = "(warning) no assert";
						haxe.unit.TestRunner.print("W");
					}
				} catch( $e0 ) {
					if( js.Boot.__instanceof($e0,haxe.unit.TestStatus) ) {
						var e = $e0;
						haxe.unit.TestRunner.print("F");
						t.currentTest.backtrace = haxe.CallStack.toString(haxe.CallStack.exceptionStack());
					} else {
					var e = $e0;
					haxe.unit.TestRunner.print("E");
					if(e.message != null) t.currentTest.error = "exception thrown : " + Std.string(e) + " [" + Std.string(e.message) + "]"; else t.currentTest.error = "exception thrown : " + Std.string(e);
					t.currentTest.backtrace = haxe.CallStack.toString(haxe.CallStack.exceptionStack());
					}
				}
				this.result.add(t.currentTest);
				t.tearDown();
			}
		}
		haxe.unit.TestRunner.print("\n");
		haxe.Log.trace = old;
	}
	,run: function() {
		this.result = new haxe.unit.TestResult();
		var $it0 = this.cases.iterator();
		while( $it0.hasNext() ) {
			var c = $it0.next();
			this.runCase(c);
		}
		haxe.unit.TestRunner.print(this.result.toString());
		return this.result.success;
	}
	,add: function(c) {
		this.cases.add(c);
	}
	,cases: null
	,result: null
	,__class__: haxe.unit.TestRunner
}
haxe.unit.TestStatus = function() {
	this.done = false;
	this.success = false;
};
$hxClasses["haxe.unit.TestStatus"] = haxe.unit.TestStatus;
haxe.unit.TestStatus.__name__ = ["haxe","unit","TestStatus"];
haxe.unit.TestStatus.prototype = {
	backtrace: null
	,posInfos: null
	,classname: null
	,method: null
	,error: null
	,success: null
	,done: null
	,__class__: haxe.unit.TestStatus
}
var hxqp = {}
hxqp.Main = function() {
	var h = new List();
};
$hxClasses["hxqp.Main"] = hxqp.Main;
hxqp.Main.__name__ = ["hxqp","Main"];
hxqp.Main.main = function() {
	var isCli = window.isCli;
	if(isCli) {
		var a = ["","test"];
		if(a[1] == "test") hxqp.TestMain.main();
		return;
	}
}
hxqp.Main.prototype = {
	tmain: function(isCli,req) {
		if(isCli) throw "js: Not implemented for this platform";
	}
	,__class__: hxqp.Main
}
hxqp.TestMain = function() {
	haxe.unit.TestCase.call(this);
};
$hxClasses["hxqp.TestMain"] = hxqp.TestMain;
hxqp.TestMain.__name__ = ["hxqp","TestMain"];
hxqp.TestMain.jprint = function(v) {
	v = StringTools.rtrim("" + Std.string(v));
	print(v);
}
hxqp.TestMain.main = function() {
	haxe.Log.trace = hxqp.XLib.xtrace;
	haxe.unit.TestRunner.print = hxqp.TestMain.jprint;
	var r = new haxe.unit.TestRunner();
	r.add(new hxqp.XLibTest());
	r.add(new utils.Test());
	r.run();
}
hxqp.TestMain.__super__ = haxe.unit.TestCase;
hxqp.TestMain.prototype = $extend(haxe.unit.TestCase.prototype,{
	__class__: hxqp.TestMain
});
hxqp.MainTest = function() {
	haxe.unit.TestCase.call(this);
};
$hxClasses["hxqp.MainTest"] = hxqp.MainTest;
hxqp.MainTest.__name__ = ["hxqp","MainTest"];
hxqp.MainTest.__super__ = haxe.unit.TestCase;
hxqp.MainTest.prototype = $extend(haxe.unit.TestCase.prototype,{
	__class__: hxqp.MainTest
});
hxqp.Project = function() { }
$hxClasses["hxqp.Project"] = hxqp.Project;
$hxExpose(hxqp.Project, "hxqp.Project");
hxqp.Project.__name__ = ["hxqp","Project"];
hxqp.Project.packageName = function() {
	return hxqp.Project.package_;
}
hxqp.Project.setURL = function(url) {
	hxqp.Project.url_ = url;
}
hxqp.Project.URL = function(name) {
	if(name == null) name = "";
	if(hxqp.Project.url_ == null) hxqp.Project.url_ = hxqp.Project.root().attr("url");
	if(hxqp.Project.url_ == null) js.Lib.alert("hxqp: no root url");
	if(hxqp.Project.url_ == null) hxqp.Project.url_ = "";
	if(name.charAt(0) == "?") {
		var q = hxqp.Project.url_.indexOf("?");
		if(q < 0) return hxqp.Project.url_ + name;
		return hxqp.Project.url_ + "&" + name.substring(1);
	}
	if(name.charAt(0) == "/") {
		var q = hxqp.Project.url_.indexOf("?");
		if(q < 0) return hxqp.Project.url_ + name;
		return hxqp.Project.url_.substring(0,q) + name + hxqp.Project.url_.substring(q);
	}
	var q = hxqp.Project.url_.indexOf("?");
	if(q < 0) return hxqp.Project.url_ + (HxOverrides.substr(hxqp.Project.url_,-1,null) == "/"?name:"/" + name);
	return hxqp.Project.url_.substring(0,q) + name + hxqp.Project.url_.substring(q);
}
hxqp.Project.root = function() {
	return $("#" + hxqp.Project.package_ + ",div[url]");
}
hxqp.Remote = function() {
};
$hxClasses["hxqp.Remote"] = hxqp.Remote;
$hxExpose(hxqp.Remote, "hxqp.Remote");
hxqp.Remote.__name__ = ["hxqp","Remote"];
hxqp.Remote.get_option = function(o) {
	return new js.JQuery("#qproject_sample_" + o).attr("value");
}
hxqp.Remote.mail = function() {
	hxqp.Remote.acall("WP.mail",[hxqp.Remote.get_option("replyTo"),"mail from qproject","..."],function(a) {
		js.Lib.alert(a);
	});
}
hxqp.Remote.tryadd = function() {
	js.Lib.alert(hxqp.Remote.call("tryadd",[1,2]));
}
hxqp.Remote.acall = function(proc,params,onResult) {
	if(params == null) params = [];
	try {
		var cnx = haxe.remoting.HttpAsyncConnection.urlConnect(hxqp.Project.URL());
		if(proc.indexOf(".") < 0) proc = "Remote." + proc;
		var _g = 0, _g1 = proc.split(".");
		while(_g < _g1.length) {
			var p = _g1[_g];
			++_g;
			cnx = cnx.resolve(p);
		}
		cnx.setErrorHandler(function(err) {
			js.Lib.alert("acall.Error:" + Std.string(err));
			throw err;
		});
		cnx.call(params,onResult == null?function(data) {
			js.Lib.alert(data);
		}:onResult);
	} catch( x ) {
		js.Lib.alert("acall:" + Std.string(x));
		throw x;
	}
}
hxqp.Remote.call = function(proc,params) {
	if(params == null) params = [];
	try {
		var cnx = haxe.remoting.HttpConnection.urlConnect(hxqp.Project.URL());
		if(proc.indexOf(".") < 0) proc = "Remote." + proc;
		var _g = 0, _g1 = proc.split(".");
		while(_g < _g1.length) {
			var p = _g1[_g];
			++_g;
			cnx = cnx.resolve(p);
		}
		var ret = cnx.call(params);
		return ret;
	} catch( x ) {
		js.Lib.alert("call:" + Std.string(x));
		throw x;
	}
}
hxqp.Remote.prototype = {
	__class__: hxqp.Remote
}
hxqp.RemoteTest = function() {
	haxe.unit.TestCase.call(this);
};
$hxClasses["hxqp.RemoteTest"] = hxqp.RemoteTest;
hxqp.RemoteTest.__name__ = ["hxqp","RemoteTest"];
hxqp.RemoteTest.__super__ = haxe.unit.TestCase;
hxqp.RemoteTest.prototype = $extend(haxe.unit.TestCase.prototype,{
	__class__: hxqp.RemoteTest
});
hxqp.TagIterator = function() { }
$hxClasses["hxqp.TagIterator"] = hxqp.TagIterator;
hxqp.TagIterator.__name__ = ["hxqp","TagIterator"];
hxqp.TagIterator.prototype = {
	next: null
	,hasNext: null
	,__class__: hxqp.TagIterator
}
hxqp.ITag = function() { }
$hxClasses["hxqp.ITag"] = hxqp.ITag;
hxqp.ITag.__name__ = ["hxqp","ITag"];
hxqp.ITag.prototype = {
	render: null
	,__class__: hxqp.ITag
}
hxqp.TagCommon = function() { }
$hxClasses["hxqp.TagCommon"] = hxqp.TagCommon;
hxqp.TagCommon.__name__ = ["hxqp","TagCommon"];
hxqp.TagCommon.testid = function(id,info) {
	if(hxqp.TagCommon.kid_.get(id) != null) {
		haxe.Log.trace(hxqp.XLib.callFrom(),{ fileName : "Tag.hx", lineNumber : 46, className : "hxqp.TagCommon", methodName : "testid"});
		throw id + ":" + info + "<=" + hxqp.TagCommon.kid_.get(id);
	}
	hxqp.TagCommon.kid_.set(id,info);
	info;
}
hxqp.TagCommon.prototype = {
	nextid: function() {
		return "temp" + ++hxqp.TagCommon.id_;
	}
	,__class__: hxqp.TagCommon
}
hxqp.Tag = function() { }
$hxClasses["hxqp.Tag"] = hxqp.Tag;
$hxExpose(hxqp.Tag, "hxqp.Tag");
hxqp.Tag.__name__ = ["hxqp","Tag"];
hxqp.Tag.includeJS = function(path) {
	if($.browser && $.browser.safari) return $.ajax({ url : path, dataType : "script", async : false, cache : true});
	var html = "<script charset='utf-8' type='text/javascript' src='" + path + "'></script>";
	if($.browser && $.browser.msie) return document.write(html);
	$("head").append(html);
}
hxqp.Tag.includeCSS = function(path) {
	var html = "<link rel='stylesheet' type='text/css' href='" + path + "' media='all'/>";
	if($.browser && $.browser.msie) return document.write(html);
	$("head").append(html);
}
hxqp.Tag.tabsReady = function(id) {
	var beforeLoad = function(event,ui) {
		ui.jqXHR.error(function() {
			ui.panel.html("Couldn't load this tab");
		});
	};
	$(id).tabs({ active : js.Cookie.get(id), beforeLoad : beforeLoad, activate : function(event,ui) {
		js.Cookie.set(id,$(id).tabs("option","active"));
	}});
}
hxqp.Tag.jqGrid = function(src,id) {
	
		if($.fn.jqGrid==undefined) jqGridInclude();
	  $('#'+id).jqGrid(
		{
	    url:hxqp.Project.URL(src),
	    datatype: 'json',
	    colNames:['ID','Name','Group','State'],
	    colModel :[ 
	      {name:'pid', index:'pid'}, 
	      {name:'name', index:'name'}, 
	      {name:'group', index:'group'},
	      {name:'state', index:'state'}, 
			],
  	}); 
		;
}
hxqp.Tag.bbGrid = function(el,ec,rowid) {
	var v = { };
	if(el.attributes && el.attributes.param) {
		if(typeof(el.attributes.param.value) == "string") v = hxqp.XLib.unserialize(el.attributes.param.value);
	}
	
	  var a = _.extend(Backbone,{
			ajax:function(o) {
				if(typeof o !== 'object') {alert('bjax.param:'+typeof(o));throw o;}
				//console.log('bjax',v.useRemote_,o.url,o);
				if(typeof o.data == 'string') o.data = JSON.parse(o.data); //dataType=json
				//if(typeof o.data !== 'object') {alert('bjax.data:'+typeof(o.data));}
				if(!v.useRemote_) 
					return Backbone.$.ajax.apply(Backbone.$,arguments);
				try
				{
					o.data = o.data || {};
					if(o.wait) 
					{
						var ret = hxqp.Remote.call('bbGrid',[o.type,o.url,rowid,o.data]);
						if(o.success) setTimeout(function(){o.success(ret);},1); // fix call order
					}
					else
					{
						hxqp.Remote.acall('bbGrid',[o.type,o.url,rowid,o.data],o.success);
					}
				} catch(x)
				{
					if(o.error) o.error(x);
				}
				return {}; //xHdr
			},
		}).Collection.extend({
			model: Backbone.Model.extend({
				idAttribute:v.id_?v.id_:'id',
				xurl: function() { 
					return v.url_; 
				} // dont backbone url/id
			}),
			url:v.url_,
			parse:function(data,options){
				//console.log(this.model.prototype.idAttribute,v.id_,data[0]);
				return data;
			},
		});
		a = new a();
		_.extend(v,{        
			container: ec==undefined?el:ec,        
			collection: a,
		});
		if(el.attributes.subid) _.extend(v,{        
			subgrid: true,
			subgridAccordion: true,
			onRowExpanded: function(ec, rowid)			
			{
				var em = $('#'+el.attributes.subid.value)[0];
        hxqp.Tag.bbGrid(em,ec,rowid);
			},
		});
		if(el.attributes.formid) _.extend(v,{buttons:[
				{title:'New',onClick:function(){hxqp.Tag.bbForm(el,this,'create')}},
				{title:'Remove',onClick:function(){hxqp.Tag.bbForm(el,this,'delete')}},
				{title:'Edit',onClick:function(){hxqp.Tag.bbForm(el,this,'update')}},
			]});
		new bbGrid.View(v);
		;
}
hxqp.Tag.bbForm = function(el,t,m) {
	var title = hxqp.XLib.ucfirst(m);
	var models = t.view.getSelectedModels();
	
		var f = $('#'+el.attributes.formid.value);
		if(!f.length) return alert(el.id+': no edit form');
		var model = _.first(models);  
		if(!model)
		{
	   	if(m!='create') return alert('Select a row');
			model = new t.model();
		}
		if(m=='create' && t.view.id_) model.attributes[t.view.id_] = model.id = undefined;
		for(var i in model.attributes) $('input[name='+i+']',f).attr('value',model.attributes[i]);
		var bb = {};
		bb.Cancel = function(){$(this).dialog('close')};
		bb[title] = function(){
			if(m=='update'||m=='create') {
				for(var i in model.attributes) model.attributes[i] = $('input[name='+i+']',f).attr('value');
				model.save();
			}
			else if(m=='delete') {
				model.destroy();
			}
			$(this).dialog('close');
		};
		f.first().dialog({
			title:'Row:'+model.id,
			width: 80*6, /// 
			buttons:bb,
		});
		;
}
hxqp.Tag.talert = function(str) {
	
			var j = $('#hxqp-Tag-talert');
			if(!j) return alert(str);
			j.text(typeof(str)+':'+str);
			j.dialog({
			modal:true,
			buttons:{OK:function(){$(this).dialog('close')}},
			})
		;
}
hxqp.Tag.__super__ = hxqp.TagCommon;
hxqp.Tag.prototype = $extend(hxqp.TagCommon.prototype,{
	__class__: hxqp.Tag
});
hxqp.XLib = function() { }
$hxClasses["hxqp.XLib"] = hxqp.XLib;
$hxExpose(hxqp.XLib, "hxqp.XLib");
hxqp.XLib.__name__ = ["hxqp","XLib"];
hxqp.XLib._typeof = function(x) {
	return typeof(x);
}
hxqp.XLib.xtrace = function(x,i) {
	var h = i == null?"":i.fileName + "." + i.lineNumber + ":";
	h += typeof(x) + "=>" + Std.string(Type.getClass(x)) + ":";
	console.log(h + Std.string(x));
}
hxqp.XLib.sprintf = function(format,Dynamic,Dynamic1,Dynamic2,Dynamic3,Dynamic4,Dynamic5,Dynamic6,Dynamic7,Dynamic8) {
	var arg = $arguments;
	if($typeof(format) != "string") return hxqp.XLib.sprintf("%o",arg);
	var i = 1;
	return format.replace(/%((%)|[soc])/g,function(f,b1,b2) {
		if(b2) return b2;
		var a = arg[i++];
		var s = "" + Std.string(a);
		if(b1 == "o") return str(a);
		if(b1 == "c") return s.charAt(0);
		return s;
	});
}
hxqp.XLib.print = function(t) {
	console.log(t);
}
hxqp.XLib.println = function(t) {
	hxqp.XLib.print(t + "\n");
}
hxqp.XLib.exit = function(ret) {
	if(ret == null) ret = 0;
	quit(ret);
}
hxqp.XLib.extend = function(t,o) {
	if(t == null) t = { };
	if(o == null) o = { };
	var _g = 0, _g1 = Reflect.fields(o);
	while(_g < _g1.length) {
		var i = _g1[_g];
		++_g;
		t[i] = Reflect.field(o,i);
	}
	return t;
}
hxqp.XLib.q = function(s) {
	return "'" + StringTools.replace(s,"'","\\'") + "'";
}
hxqp.XLib.qq = function(s) {
	return "\"" + StringTools.replace(s,"\"","\\\"") + "\"";
}
hxqp.XLib.serialize = function(o,q) {
	if(q == null) q = 0;
	var t = new haxe.Serializer();
	t.serialize(o);
	var s = t.toString();
	if(q == 1) s = "'" + StringTools.replace(s,"'","\\'") + "'";
	if(q == 2) s = "\"" + StringTools.replace(s,"\"","\\\"") + "\"";
	return s;
}
hxqp.XLib.unserialize = function(s) {
	return new haxe.Unserializer(s).unserialize();
}
hxqp.XLib.callFrom = function(n) {
	if(n == null) n = 1;
	return "";
}
hxqp.XLib.ucfirst = function(m) {
	return HxOverrides.substr(m,0,1).toUpperCase() + HxOverrides.substr(m,1,null);
}
hxqp.XLibTest = function() {
	haxe.unit.TestCase.call(this);
};
$hxClasses["hxqp.XLibTest"] = hxqp.XLibTest;
hxqp.XLibTest.__name__ = ["hxqp","XLibTest"];
hxqp.XLibTest.__super__ = haxe.unit.TestCase;
hxqp.XLibTest.prototype = $extend(haxe.unit.TestCase.prototype,{
	testStack: function() {
		hxqp.XLib.callFrom();
		this.assertEquals(1,1,{ fileName : "XLib.hx", lineNumber : 309, className : "hxqp.XLibTest", methodName : "testStack"});
	}
	,__class__: hxqp.XLibTest
});
var js = {}
js.Boot = function() { }
$hxClasses["js.Boot"] = js.Boot;
js.Boot.__name__ = ["js","Boot"];
js.Boot.__unhtml = function(s) {
	return s.split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;");
}
js.Boot.__trace = function(v,i) {
	var msg = i != null?i.fileName + ":" + i.lineNumber + ": ":"";
	msg += js.Boot.__string_rec(v,"");
	if(i != null && i.customParams != null) {
		var _g = 0, _g1 = i.customParams;
		while(_g < _g1.length) {
			var v1 = _g1[_g];
			++_g;
			msg += "," + js.Boot.__string_rec(v1,"");
		}
	}
	var d;
	if(typeof(document) != "undefined" && (d = document.getElementById("haxe:trace")) != null) d.innerHTML += js.Boot.__unhtml(msg) + "<br/>"; else if(typeof(console) != "undefined" && console.log != null) console.log(msg);
}
js.Boot.__string_rec = function(o,s) {
	if(o == null) return "null";
	if(s.length >= 5) return "<...>";
	var t = typeof(o);
	if(t == "function" && (o.__name__ || o.__ename__)) t = "object";
	switch(t) {
	case "object":
		if(o instanceof Array) {
			if(o.__enum__) {
				if(o.length == 2) return o[0];
				var str = o[0] + "(";
				s += "\t";
				var _g1 = 2, _g = o.length;
				while(_g1 < _g) {
					var i = _g1++;
					if(i != 2) str += "," + js.Boot.__string_rec(o[i],s); else str += js.Boot.__string_rec(o[i],s);
				}
				return str + ")";
			}
			var l = o.length;
			var i;
			var str = "[";
			s += "\t";
			var _g = 0;
			while(_g < l) {
				var i1 = _g++;
				str += (i1 > 0?",":"") + js.Boot.__string_rec(o[i1],s);
			}
			str += "]";
			return str;
		}
		var tostr;
		try {
			tostr = o.toString;
		} catch( e ) {
			return "???";
		}
		if(tostr != null && tostr != Object.toString) {
			var s2 = o.toString();
			if(s2 != "[object Object]") return s2;
		}
		var k = null;
		var str = "{\n";
		s += "\t";
		var hasp = o.hasOwnProperty != null;
		for( var k in o ) { ;
		if(hasp && !o.hasOwnProperty(k)) {
			continue;
		}
		if(k == "prototype" || k == "__class__" || k == "__super__" || k == "__interfaces__" || k == "__properties__") {
			continue;
		}
		if(str.length != 2) str += ", \n";
		str += s + k + " : " + js.Boot.__string_rec(o[k],s);
		}
		s = s.substring(1);
		str += "\n" + s + "}";
		return str;
	case "function":
		return "<function>";
	case "string":
		return o;
	default:
		return String(o);
	}
}
js.Boot.__interfLoop = function(cc,cl) {
	if(cc == null) return false;
	if(cc == cl) return true;
	var intf = cc.__interfaces__;
	if(intf != null) {
		var _g1 = 0, _g = intf.length;
		while(_g1 < _g) {
			var i = _g1++;
			var i1 = intf[i];
			if(i1 == cl || js.Boot.__interfLoop(i1,cl)) return true;
		}
	}
	return js.Boot.__interfLoop(cc.__super__,cl);
}
js.Boot.__instanceof = function(o,cl) {
	if(cl == null) return false;
	switch(cl) {
	case Int:
		return (o|0) === o;
	case Float:
		return typeof(o) == "number";
	case Bool:
		return typeof(o) == "boolean";
	case String:
		return typeof(o) == "string";
	case Dynamic:
		return true;
	default:
		if(o != null) {
			if(typeof(cl) == "function") {
				if(o instanceof cl) {
					if(cl == Array) return o.__enum__ == null;
					return true;
				}
				if(js.Boot.__interfLoop(o.__class__,cl)) return true;
			}
		} else return false;
		if(cl == Class && o.__name__ != null) return true;
		if(cl == Enum && o.__ename__ != null) return true;
		return o.__enum__ == cl;
	}
}
js.Browser = function() { }
$hxClasses["js.Browser"] = js.Browser;
js.Browser.__name__ = ["js","Browser"];
js.Browser.createXMLHttpRequest = function() {
	if(typeof XMLHttpRequest != "undefined") return new XMLHttpRequest();
	if(typeof ActiveXObject != "undefined") return new ActiveXObject("Microsoft.XMLHTTP");
	throw "Unable to create XMLHttpRequest object.";
}
js.Cookie = function() { }
$hxClasses["js.Cookie"] = js.Cookie;
js.Cookie.__name__ = ["js","Cookie"];
js.Cookie.set = function(name,value,expireDelay,path,domain) {
	var s = name + "=" + StringTools.urlEncode(value);
	if(expireDelay != null) {
		var d = DateTools.delta(new Date(),expireDelay * 1000);
		s += ";expires=" + d.toGMTString();
	}
	if(path != null) s += ";path=" + path;
	if(domain != null) s += ";domain=" + domain;
	js.Browser.document.cookie = s;
}
js.Cookie.all = function() {
	var h = new haxe.ds.StringMap();
	var a = js.Browser.document.cookie.split(";");
	var _g = 0;
	while(_g < a.length) {
		var e = a[_g];
		++_g;
		e = StringTools.ltrim(e);
		var t = e.split("=");
		if(t.length < 2) continue;
		h.set(t[0],StringTools.urlDecode(t[1]));
	}
	return h;
}
js.Cookie.get = function(name) {
	return js.Cookie.all().get(name);
}
js.Lib = function() { }
$hxClasses["js.Lib"] = js.Lib;
js.Lib.__name__ = ["js","Lib"];
js.Lib.alert = function(v) {
	alert(js.Boot.__string_rec(v,""));
}
var utils = {}
utils.URLParser = function(url) {
	this.url = url;
	var r = new EReg("^(?:(?![^:@]+:[^:@/]*@)([^:/?#.]+):)?(?://)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:/?#]*)(?::(\\d*))?)(((/(?:[^?#](?![^?#/]*\\.[^?#/.]+(?:[?#]|$)))*/?)?([^?#/]*))(?:\\?([^#]*))?(?:#(.*))?)","");
	this.ok = r.match(url);
	var _g1 = 0, _g = utils.URLParser._parts.length;
	while(_g1 < _g) {
		var i = _g1++;
		this[utils.URLParser._parts[i]] = r.matched(i);
	}
};
$hxClasses["utils.URLParser"] = utils.URLParser;
utils.URLParser.__name__ = ["utils","URLParser"];
utils.URLParser.parse = function(url) {
	return new utils.URLParser(url);
}
utils.URLParser.prototype = {
	test: function() {
		var s = "For Url -> " + this.url + "\n";
		var _g1 = 0, _g = utils.URLParser._parts.length;
		while(_g1 < _g) {
			var i = _g1++;
			s += utils.URLParser._parts[i] + ":[" + Std.string(Reflect.field(this,utils.URLParser._parts[i])) + "]\n";
		}
		s += "query:" + Std.string(this.desplit("query")) + "\n";
		s += "anchor:" + Std.string(this.desplit("anchor")) + "\n";
		return s;
	}
	,toString: function() {
		return this.source;
	}
	,desplit: function(key) {
		if(key == null) key = "query";
		var ret = { };
		var str = Reflect.field(this,key);
		if(str != null) {
			var _g = 0, _g1 = str.split("&");
			while(_g < _g1.length) {
				var pp = _g1[_g];
				++_g;
				var i = pp.indexOf("=");
				if(i < 0) {
					ret[pp] = true;
					continue;
				}
				var k = pp.substring(0,i);
				var v = pp.substring(i + 1);
				k = StringTools.urlDecode(k);
				v = StringTools.urlDecode(v);
				ret[k] = v;
			}
		}
		return ret;
	}
	,anchor: null
	,query: null
	,file: null
	,directory: null
	,path: null
	,relative: null
	,port: null
	,host: null
	,password: null
	,user: null
	,userInfo: null
	,authority: null
	,protocol: null
	,source: null
	,ok: null
	,url: null
	,__class__: utils.URLParser
}
utils.Test = function() {
	haxe.unit.TestCase.call(this);
};
$hxClasses["utils.Test"] = utils.Test;
utils.Test.__name__ = ["utils","Test"];
utils.Test.__super__ = haxe.unit.TestCase;
utils.Test.prototype = $extend(haxe.unit.TestCase.prototype,{
	testtest: function() {
		var err = "";
		var _g = 0, _g1 = utils.Test.u2;
		while(_g < _g1.length) {
			var u = _g1[_g];
			++_g;
			try {
				haxe.Log.trace(utils.URLParser.parse(u).test(),{ fileName : "URLParser.hx", lineNumber : 130, className : "utils.Test", methodName : "testtest"});
			} catch( x ) {
				if( js.Boot.__instanceof(x,utils.Test) ) {
					err = "" + Std.string(x);
				} else throw(x);
			}
		}
		this.assertEquals("",err,{ fileName : "URLParser.hx", lineNumber : 132, className : "utils.Test", methodName : "testtest"});
	}
	,testParse: function() {
		var _g = 0, _g1 = utils.Test.u1;
		while(_g < _g1.length) {
			var u = _g1[_g];
			++_g;
			this.assertEquals(u,utils.URLParser.parse(u).toString(),{ fileName : "URLParser.hx", lineNumber : 122, className : "utils.Test", methodName : "testParse"});
		}
		var _g = 0, _g1 = utils.Test.u2;
		while(_g < _g1.length) {
			var u = _g1[_g];
			++_g;
			this.assertEquals(u,utils.URLParser.parse(u).toString(),{ fileName : "URLParser.hx", lineNumber : 123, className : "utils.Test", methodName : "testParse"});
		}
	}
	,__class__: utils.Test
});
function $iterator(o) { if( o instanceof Array ) return function() { return HxOverrides.iter(o); }; return typeof(o.iterator) == 'function' ? $bind(o,o.iterator) : o.iterator; };
var $_, $fid = 0;
function $bind(o,m) { if( m == null ) return null; if( m.__id__ == null ) m.__id__ = $fid++; var f; if( o.hx__closures__ == null ) o.hx__closures__ = {}; else f = o.hx__closures__[m.__id__]; if( f == null ) { f = function(){ return f.method.apply(f.scope, arguments); }; f.scope = o; f.method = m; o.hx__closures__[m.__id__] = f; } return f; };
if(Array.prototype.indexOf) HxOverrides.remove = function(a,o) {
	var i = a.indexOf(o);
	if(i == -1) return false;
	a.splice(i,1);
	return true;
};
Math.__name__ = ["Math"];
Math.NaN = Number.NaN;
Math.NEGATIVE_INFINITY = Number.NEGATIVE_INFINITY;
Math.POSITIVE_INFINITY = Number.POSITIVE_INFINITY;
$hxClasses.Math = Math;
Math.isFinite = function(i) {
	return isFinite(i);
};
Math.isNaN = function(i) {
	return isNaN(i);
};
String.prototype.__class__ = $hxClasses.String = String;
String.__name__ = ["String"];
Array.prototype.__class__ = $hxClasses.Array = Array;
Array.__name__ = ["Array"];
Date.prototype.__class__ = $hxClasses.Date = Date;
Date.__name__ = ["Date"];
var Int = $hxClasses.Int = { __name__ : ["Int"]};
var Dynamic = $hxClasses.Dynamic = { __name__ : ["Dynamic"]};
var Float = $hxClasses.Float = Number;
Float.__name__ = ["Float"];
var Bool = $hxClasses.Bool = Boolean;
Bool.__ename__ = ["Bool"];
var Class = $hxClasses.Class = { __name__ : ["Class"]};
var Enum = { };

		if(typeof window == 'undefined') window={};
		if(typeof print != 'function') no_print_function();
		if(typeof console == 'undefined') console={log:function(a){print(a)}};
		if(typeof alert != 'function') alert=function(a){print(a)};
		//if(typeof $ == 'undefined') alert('Main:no$');
		$hxClasses['XHList'] = List;
		;
var q = window.jQuery;
js.JQuery = q;
utils.URLParser._parts = ["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"];
haxe.Serializer.USE_CACHE = false;
haxe.Serializer.USE_ENUM_INDEX = false;
haxe.Serializer.BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%:";
haxe.Unserializer.DEFAULT_RESOLVER = Type;
haxe.Unserializer.BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789%:";
haxe.ds.ObjectMap.count = 0;
hxqp.Main.__meta__ = { statics : { main : { any : null}}, fields : { tmain : { js : null}, _ : { any : null}}};
hxqp.TestMain.print_ = haxe.unit.TestRunner.print;
hxqp.Project.package_ = "hxqp";
hxqp.TagCommon.nocache_ = true;
hxqp.TagCommon.id_ = 0;
hxqp.TagCommon.kid_ = new haxe.ds.StringMap();
hxqp.Tag.__meta__ = { statics : { includeJS : { js : null}, includeCSS : { js : null}, tabsReady : { js : null}, jqGrid : { js : null}, bbGrid : { js : null}, bbForm : { js : null}, talert : { js : null}}};
hxqp.XLib.__meta__ = { statics : { _typeof : { js : null}, xtrace : { js : null}, sprintf : { js : null}, print : { js : null}, println : { any : null}, exit : { js : null}, extend : { any : null}, q : { any : null}, qq : { any : null}, serialize : { any : null}, unserialize : { any : null}, callFrom : { js : null}, ucfirst : { js : null}}};
js.Browser.document = typeof window != "undefined" ? window.document : null;
utils.Test.u1 = ["/hello/world/there.html?name=ferret#foo","foo://username:password@www.example.com:123/hello/world/there.html?name=ferret#foo","mailto::a@x","?a=1&b=2","?a=1&b=2?c=3&d=4","?T=TLink[pid=:1].user()"];
utils.Test.u2 = ["http://a.com?a=1#c=2&b=2","?a=1&b=2/3"];
hxqp.Main.main();
function $hxExpose(src, path) {
	var o = typeof window != "undefined" ? window : exports;
	var parts = path.split(".");
	for(var ii = 0; ii < parts.length-1; ++ii) {
		var p = parts[ii];
		if(typeof o[p] == "undefined") o[p] = {};
		o = o[p];
	}
	o[parts[parts.length-1]] = src;
}
})();
